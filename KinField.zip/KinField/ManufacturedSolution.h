#ifndef ManSol

#define ManSol
double getmanH(double x, double y, double t);
double getQx(double x, double y, double t);
double getQy(double x, double y, double t);

double getS1(double x, double y, double t);
double getS2(double x, double y, double t);
double getS3(double x, double y, double t);

#endif
