#!/bin/bash

gcc -std=c99 -g -o main process_mesh.c -lm
