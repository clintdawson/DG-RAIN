#ifndef ONE_TIME_STEP

#define ONE_TIME_STEP

extern void computeKinL(double time);
extern void minmod();
extern void boundary_conditions();

#endif
