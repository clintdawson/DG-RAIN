import os
import numpy as np
import matplotlib.pyplot as plt
from matplotlib import rc_file

NumFilePath = "/workspace/prapti/results/preliminaryResults/ParkingLot2/OutflowRate.dat"
TrueSolPath="/workspace/prapti/results/preliminaryResults/ParkingLot2/TrueSolution.txt"

NumSol = np.loadtxt(NumFilePath)
TrueSol = np.loadtxt(TrueSolPath)

t_num = NumSol[:,0]
Qval = NumSol[:,1]
t_true = TrueSol[:,0]
firstStorm = TrueSol[:,1]
secondStorm = TrueSol[:,2]
combinedStorm = TrueSol[:,3]

currdir = os.getcwd()
rc_file(currdir+'/my_matplotlib.rc')
fig = plt.figure()
lines = plt.plot(t_num, Qval, '-', t_true, firstStorm, '*--', t_true, secondStorm, '*--', t_true, combinedStorm, '-')
plt.setp(lines[0], color='blue', linewidth = 2.0)
plt.setp(lines[1], color='green', linewidth=2.0)
plt.setp(lines[2], color='red', linewidth = 2.0)
plt.setp(lines[3], color='magenta', linewidth=2.0)
plt.legend(lines, [r"DG Solution", r"First Storm", r"Second Storm", r"Semi-analytic Solution"])  
plt.ylabel(r"Outflow Rate (ft^2/\textup{min})")
plt.xlabel(r"Time (min)")
plt.axis([0,20,0,0.7])
#plt.show()
plt.tight_layout(pad=0.1)
fileName="/workspace/prapti/dissertation/Pictures/ParkingLot2OutflowRate.pdf"
plt.savefig(fileName, bbox_inches='tight', transparent=True, pad_inches=0)
plt.close()

