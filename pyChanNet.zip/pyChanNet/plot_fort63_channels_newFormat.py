import os
import sys
import numpy as np
import matplotlib
import matplotlib.tri as tri
from matplotlib import rc_file
import matplotlib.pyplot as plt
from moviepy.video.io.bindings import mplfig_to_npimage
import moviepy.editor as mpy
import matplotlib.patches as mpatches
from matplotlib.path import Path
from matplotlib.collections import PatchCollection
import my_io
from plot_channels_and_junctions import read_junctions_grid_file
from plot_channels_and_junctions import read_channels_grid_file
from plot_channels_and_junctions import read_channels_63
from plot_channels_and_junctions import read_junctions_63


def read_fort63(path):
	fort63_file = open(path, 'r')

	# Read header
	fort63_file.readline()
	
	# Read the second line
	[num_time_snaps, num_vals, dummy1, dummy2, dummy3] = fort63_file.readline().split()
	num_time_snaps = int(num_time_snaps)
	num_vals = int(num_vals)

	vals = np.empty((num_vals,num_time_snaps))
	time_array = np.empty((num_time_snaps,1))
	for snap in xrange(num_time_snaps):
		# Read current time and time step info
		line = fort63_file.readline()
		[time, time_step_num] = line.split()
		time = float(time)
		time_step_num = int(time_step_num)
		time_array[snap,0] = time

		for node in xrange(num_vals):
			[el_num, val] = fort63_file.readline().split()
			el_num = int(el_num)
			vals[node,snap]= float(val)
		
	return vals, time_array

def plot_Watershed(bayTriangulation, junctionTriangulationList, bayDataField, junctionDataFieldList, Rect_Boxes, DataBoxesVals, vmin=None, vmax=None, plt_title=None, plt_name=None):
	currdir = os.getcwd()
	rc_file(currdir+'/my_matplotlib.rc')

	fig = plt.figure()
	ax = plt.subplot(1,1,1)

	ax.set_xlim(-200,200)
	ax.set_ylim(-500, 410)
# adjust ticks on the x-axis
	ax.locator_params(axis='x', nbins=3)
	cmap = plt.get_cmap('jet')
	plt.gca().set_aspect('equal')
	
# plot junction data
	num_junctions = len(junctionTriangulationList)
	for j in xrange(num_junctions):
		triangulation = junctionTriangulationList[j]
		data_field = np.array(junctionDataFieldList[j])
		plt.tripcolor(triangulation, facecolors=data_field, edgecolors='w',vmin=vmin, vmax=vmax, cmap=cmap)

# plot bay data
	plt.tripcolor(bayTriangulation, facecolors=bayDataField, edgecolors='w', vmin=vmin, vmax=vmax, cmap=cmap)

	# plot chanels data
	codes = [Path.MOVETO, Path.LINETO, Path.LINETO, Path.LINETO, Path.CLOSEPOLY,]
	patches = []
	for verts in Rect_Boxes:
		path = Path(verts, codes)
		patch = mpatches.PathPatch(path, lw=2)
		patches.append(patch)

	Channels = PatchCollection(patches, cmap=cmap, alpha=1.0)
	Channels.set_array(np.array(DataBoxesVals))
	Channels.set_clim([vmin, vmax])
	ax.add_collection(Channels)	
	plt.colorbar()

	if (plt_title):
		plt.title(plt_title, y=1.05, fontsize=20)
	if (plt_name):
		plt.savefig(plt_name, transparent=False)
	else:
		plt.show()

	plt.close()	
	

def make_pngs(workingDir):
	bayGridFilePath = workingDir+"/fort.14"
	junctionsGridFilePath = workingDir+"/Junctions.14"
	channelsGridFilePath = workingDir+"/Channels.14"

	fort63Path = workingDir+"/fort.63"
	Channels63Path = workingDir+"/Channels.63"
	Junctions63Path = workingDir+"/Junctions.63"

# read in grid files
	junctionTriangulationArray = read_junctions_grid_file(junctionsGridFilePath)

	bay_num_elements, bay_num_nodes, bay_coords, bay_bathymetry, bay_Triangles = my_io.read_grid_data(bayGridFilePath)
	
	bay_triangulation = tri.Triangulation(bay_coords[:,0], bay_coords[:,1], triangles=bay_Triangles)

	rectangularBoxes = read_channels_grid_file(channelsGridFilePath)

# read data files
	Junctions_time_array, Junctions_H_array, Junctions_Zeta_array = read_junctions_63(Junctions63Path)
	Channels_H_array, Channels_Zeta_array = read_channels_63(Channels63Path)

	bay_data_array, bay_time_array = read_fort63(fort63Path)
	#tri_bath = (bathymetry[Triangles[:,0]] + bathymetry[Triangles[:,1]] + bathymetry[Triangles[:,2]])/3
	[bay_num_vals, bay_num_snaps] = bay_data_array.shape
	bay_num_vals = int(bay_num_vals)
	bay_num_snaps = int(bay_num_snaps)

	junctions_num_snaps = len(Junctions_Zeta_array)
	channels_num_snaps = len(Channels_Zeta_array)

	if (junctions_num_snaps != bay_num_snaps or channels_num_snaps != bay_num_snaps):
		print "the number of time snaps available for the bay does not match with that available for junctions and channels"
		print "channels_num_snaps = ", channels_num_snaps, " junctions_num_snaps = ", junctions_num_snaps, " bay_num_snaps = ", bay_num_snaps
		print "correct that and try again"
		sys.exit()

	vmin = np.amin(np.amin(Junctions_Zeta_array))
	vmax = np.amax(np.amax(Junctions_Zeta_array))
	vmin_ch = np.amin(Channels_Zeta_array)
	vmax_ch = np.amax(Channels_Zeta_array)
	vmin_bay = np.amin(bay_data_array)
	vmax_bay = np.amax(bay_data_array)

	vmin = min(vmin, vmin_ch)
	vmin = min(vmin, vmin_bay)
	vmax = max(vmax, vmax_ch)
	vmax = max(vmax, vmax_bay)

	pngList = []
	for snap in xrange(bay_num_snaps):
		title = "Water surface elevation at time {} s".format(bay_time_array[snap,0])
		figName = workingDir+"/WatershedElevationEnlarged{}.png".format(snap)
		plot_Watershed(bay_triangulation, junctionTriangulationArray, bay_data_array[:,snap], Junctions_Zeta_array[snap], rectangularBoxes, Channels_Zeta_array[snap], vmin=vmin, vmax=vmax, plt_title=title, plt_name=figName)

		pngList.append(figName)

	return pngList


def make_movie(workingDir, pngList):
	clip = mpy.ImageSequenceClip(pngList, fps=4)
	#clip.write_videofile(workingDir+'/Animation_Enlarged.mp4')
	clip.write_videofile(workingDir+'/WatershedFloodingEnlarged.mp4')
	#clip.write_videofile(workingDir+'/Animation_Enlarged.avi', codec='png')

def main(argv):
	workingDir = argv[1]
	png_list = make_pngs(workingDir)
	make_movie(workingDir,png_list)

if __name__ == "__main__":
	main(sys.argv)

