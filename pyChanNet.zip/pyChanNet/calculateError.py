import os
import numpy as np
import matplotlib.pyplot as plt
from matplotlib import rc_file
from math import sqrt

ZetaFilePath="/h2/prapti/workrepo/ChannelNetwork/2DCode/Tmesh/CoarseGrid/PlotVal1"
#figName="/workspace/prapti/Dropbox/Proposal Documents/Presentation/Pictures/Fully2DZetaVsExperimental1.pdf"
#ZetaFilePath="/h2/prapti/workrepo/ChannelNetwork/src/JunctionMeshedSeparately/TChannel/LargerJunctionSize/CoarseJunctionMesh/PlotVal"
#figName="/workspace/prapti/Dropbox/Proposal Documents/Presentation/Pictures/LargeJunctionZetaVsExperimental1.pdf"
#ZetaFilePath="/h2/prapti/workrepo/ChannelNetwork/src/JunctionMeshedSeparately/TChannel/SmallerJunctionSize/CoarseMesh/PlotVal"
figName="/workspace/prapti/Dropbox/Proposal Documents/Presentation/Pictures/SmallJunctionZetaVsExperimental.pdf"
analyticZetaPath="/workspace/prapti/Dropbox/ChannelNetworksPaper/ExperimentalData.dat"

#ZetaFilePath="/h2/prapti/workrepo/ChannelNetwork/2DCode/AngledTMesh/Channel2"
#figName="/workspace/prapti/Dropbox/ChannelNetworksPaper/Pictures/AngledFully2DVsOtherModelsChannel2.pdf"
##ZetaFilePath="/h2/prapti/workrepo/ChannelNetwork/src/JunctionMeshedSeparately/AngledChannel/Zeta0"
##figName="/workspace/prapti/Dropbox/ChannelNetworksPaper/Pictures/JunctionModelVsOtherModelsChannel0.pdf"
#analyticZetaPath="/workspace/prapti/Dropbox/ChannelNetworksPaper/ShabayekModelChannel2.dat"
#EqualityPath="/workspace/prapti/Dropbox/ChannelNetworksPaper/EqualityModelChannel2.dat"


Experimental1 = np.loadtxt(analyticZetaPath);
#Experimental2 = np.loadtxt(EqualityPath);
Numerical = np.loadtxt(ZetaFilePath);

x_experimental1 = Experimental1[:,0];
H_experimental1 = Experimental1[:,1];
#x_experimental2 = Experimental2[:,0];
#H_experimental2 = Experimental2[:,1];
x_numerical = Numerical[:,0];
H_numerical = Numerical[:,1];

x_numerical1 = Numerical[:,2];
H_numerical1 = Numerical[:,3];

x_numerical2 = Numerical[:,4];
H_numerical2 = Numerical[:,5];

# flip numerical x and H
x_numerical_sorted = np.empty(x_numerical.shape)
H_numerical_sorted = np.empty(H_numerical.shape)
x_numerical_sorted1 = np.empty(x_numerical1.shape)
H_numerical_sorted1 = np.empty(H_numerical1.shape)
x_numerical_sorted2 = np.empty(x_numerical2.shape)
H_numerical_sorted2 = np.empty(H_numerical2.shape)
for i in range(len(x_numerical)):
	x_numerical_sorted[i] = x_numerical[len(x_numerical)-i-1]
	H_numerical_sorted[i] = H_numerical[len(H_numerical)-i-1]
	x_numerical_sorted1[i] = x_numerical1[len(x_numerical)-i-1]
	H_numerical_sorted1[i] = H_numerical1[len(H_numerical)-i-1]
	x_numerical_sorted2[i] = x_numerical2[len(x_numerical)-i-1]
	H_numerical_sorted2[i] = H_numerical2[len(H_numerical)-i-1]


currdir = os.getcwd()
rc_file(currdir+'/my_matplotlib.rc')
fig = plt.figure()
lines = plt.plot(x_experimental1, H_experimental1, '*', x_numerical2, H_numerical2)

#lines = plt.plot(x_experimental1, H_experimental1, '*', x_experimental2, H_experimental2, '+', x_numerical, H_numerical)
#lines = plt.plot(x_experimental1, H_experimental1, '*', x_numerical_sorted, H_numerical_sorted, '-', x_numerical_sorted1, H_numerical_sorted1,'--', x_numerical_sorted2,H_numerical_sorted2)
plt.setp(lines[0], color='red', linewidth = 2.0)
plt.setp(lines[1], color='magenta', linewidth=2.0)
#plt.setp(lines[2], color='blue', linewidth=2.0)
#plt.setp(lines[3], color='purple', linewidth=2.0)
#plt.setp(lines[1], color='blue', linewidth = 2.0)
#plt.setp(lines[2], color='magenta', linewidth=2.0)
#plt.legend(lines, [r"Experimental Value", r"Numerical Solution"],loc=2)  
#plt.legend(lines, [r"Experimental Value", r"Fully 2D Solution", r"Large Junction Solution", r"Small Junction Solution"],loc=4)  
#plt.legend(lines, [r"Experimental Value", r"Small Junction Solution"],loc=4)  
#plt.legend(lines, [r"Shabayek Model", r"Equality Model", r"Fully 2D Solution"],loc=1)  
#plt.legend(lines, [r"Shabayek Model", r"Equality Model", r"Heterogeneous Junction Model"],loc=1)  
plt.ylabel(r'$\zeta^*$')
#plt.ylabel("Water Surface Height")
plt.xlabel(r'x^*')
#plt.xlabel("Distance (m)")
#plt.axis([0,601,1.2,2.5])
plt.axis([-7,2.2,0.29,0.375])
#plt.show()
plt.tight_layout(pad=0.1)
plt.savefig(figName, bbox_inches='tight', transparent=True, pad_inches=0)
plt.close()


#NumericalHeight = np.empty(x_experimental1.shape);
#
#j = 0
#for x in x_experimental1:
#	for i in range(len(x_numerical)-1):
#		if (x_numerical[i] >= x and x_numerical[i+1] <= x):
#			t = (x_numerical[i+1] -x)/(x_numerical[i+1] -x_numerical[i]);
#			NumericalHeight[j] = t*H_numerical[i] + (1-t)*H_numerical[i+1];
#			j = j+1;
#			break;
#
#diff = np.absolute(H_experimental1-NumericalHeight)
#
#error = 0
#normfactor = 0
#for i in range(len(diff)):
#	error += diff[i]**2
#	normfactor += H_experimental1[i]**2
#
#error =sqrt(error);
#print "RawL2Error = ", error
#normfactor = sqrt(normfactor);
#
#l2Error = error/normfactor
#print "NormalizedL2Error = ", l2Error
#
#errorInd = np.argmax(diff)
#error = np.amax(diff)
#print "x = ", x_experimental1[errorInd], "anal = ", H_experimental1[errorInd], "\t numerical = ", NumericalHeight[errorInd]
#print "linferror =", error
#print "percentError =", error/H_experimental1[errorInd]

