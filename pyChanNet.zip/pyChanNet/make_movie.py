from moviepy.video.io.bindings import mplfig_to_npimage
import moviepy.editor as mpy

def make_movie(workingDir, pngList):
	clip = mpy.ImageSequenceClip(pngList, fps=8)
	#clip.write_videofile(workingDir+'/Animation.avi',codec='png')
	clip.write_videofile(workingDir+'.mp4')

workingDir = 'FloodPlain'
png_list =[]
for i in xrange(60):
	name = workingDir+'/Ele{}.png'.format(i)
	png_list.append(name)

make_movie(workingDir,png_list)

