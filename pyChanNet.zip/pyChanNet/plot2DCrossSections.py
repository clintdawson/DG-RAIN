import os
import numpy as np
import matplotlib.pyplot as plt
from matplotlib import rc_file

#TestCase = ['SmoothSubcriticalFlow'];
#TestCase = ['SmoothTranscriticalFlow'];
#TestCase = ['TranscriticalFlowShock'];
#TestCase = ['MacDonaldSmoothTransitionShock']
TestCase = ['ParabolicBowl']

for case in TestCase:
	#analyticSolPath = "/h2/prapti/workrepo/ChannelNetwork/2DCode/{testCase}/data/realZeta.dat".format(testCase=case);
	dataFilePath = "/h2/prapti/workrepo/ChannelNetwork/2DCode/{testCase}/data/TwoThirdsPeriod.dat".format(testCase=case);

	#analyticSol = np.loadtxt(analyticSolPath)
	numSol = np.loadtxt(dataFilePath)

	AnalyticVal = numSol[:,3]
	x_numerical = numSol[:,0]
	NumVal = numSol[:,2]
	z = numSol[:,1]
	x_coord = x_numerical


	currdir = os.getcwd()
	rc_file(currdir+'/my_matplotlib.rc')
	fig = plt.figure()
	lines = plt.plot(x_coord, z, x_coord, AnalyticVal, x_numerical, NumVal, '--')
	plt.setp(lines[0], color='red', linewidth = 2.0)
	plt.setp(lines[1], color = 'blue', linewidth = 2.0)
	plt.setp(lines[2], color='magenta', linewidth=2.75)
	plt.legend(lines, [r"Bottom Elevation", r"Analytical Solution", r"DG Solution"])  
	plt.ylabel("Water Surface Height")
	plt.xlabel("x")
	plt.axis([0,4.0,-0.1,0.4])
	#plt.show()
	plt.tight_layout(pad=0.1)
	fileName='/workspace/prapti/Dropbox/ChannelNetworksPaper/Pictures/ParabolicBowlTwoThirdsPeriod2D.pdf'.format(case)
	#fileName='/workspace/prapti/Dropbox/ChannelNetworksPaper/Pictures/{}2D.pdf'.format(case)
	plt.savefig(fileName, bbox_inches='tight', transparent=True, pad_inches=0)
	plt.close()

