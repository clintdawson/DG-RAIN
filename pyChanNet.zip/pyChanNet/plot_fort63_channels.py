import os
import sys
import numpy as np
import matplotlib
import matplotlib.tri as tri
from matplotlib import rc_file
import matplotlib.pyplot as plt
from moviepy.video.io.bindings import mplfig_to_npimage
import moviepy.editor as mpy
import matplotlib.patches as mpatches
from matplotlib.collections import PatchCollection
import my_io

def read_fort63(path):
	fort63_file = open(path, 'r')

	# Read header
	fort63_file.readline()
	
	# Read the second line
	[num_time_snaps, num_vals, dummy1, dummy2, dummy3] = fort63_file.readline().split()
	num_time_snaps = int(num_time_snaps)
	num_vals = int(num_vals)

	vals = np.empty((num_vals,num_time_snaps))
	time_array = np.empty((num_time_snaps,1))
	for snap in xrange(num_time_snaps):
		# Read current time and time step info
		line = fort63_file.readline()
		[time, time_step_num] = line.split()
		time = float(time)
		time_step_num = int(time_step_num)
		time_array[snap,0] = time

		for node in xrange(num_vals):
			[el_num, val] = fort63_file.readline().split()
			el_num = int(el_num)
			vals[node,snap]= float(val)
		
	return vals, time_array

def plot_hybrid_data(Coords2D, trianglesArray, data_field_2D, chan_coords, Chan_ds, chanVals, chanBreadth=1, plt_title=None, vmin=None, vmax=None, plt_name=None):
	currdir = os.getcwd()
	rc_file(currdir+'/my_matplotlib.rc')
	triangulation = tri.Triangulation(Coords2D[:,0],Coords2D[:,1],triangles=trianglesArray)
	fig  = plt.figure()
	ax = plt.subplot(1,1,1)	
	plt.gca().set_aspect('equal')
	cmap = plt.get_cmap('jet')
	#print "data_field_2D(200) = ", data_field_2D[199]
	#print data_field_2D
	plt.tripcolor(triangulation, facecolors=data_field_2D, edgecolors='w',vmin=vmin, vmax=vmax, cmap=cmap)
	
	# plot channels data
	x_coords = chan_coords[:,0]
	y_coords = chan_coords[:,1]
	num_data_points = len(x_coords)
	patches = []
	for i in xrange(num_data_points):
		rect_box = mpatches.Rectangle((x_coords[i], y_coords[i]-Chan_ds[i]/2),chanBreadth,Chan_ds[i],ec=None)
		patches.append(rect_box)
	
	# create collection of patches
	Chan = PatchCollection(patches, cmap=cmap, alpha=1.0)
	Chan.set_array(np.array(chanVals))
	Chan.set_clim([vmin, vmax])
	ax.add_collection(Chan)
	
	
	# format the axis and colorbar
	plt.axis([-610,610,-1250,650])
	plt.xlabel('x')
	plt.ylabel('y')
	plt.locator_params(axis='x', nbins=6)
				
	plt.colorbar()
	
	if (plt_title != None):
			ax.set_title(plt_title)
				
	ax.set_xlabel(r'$x$', fontsize=18)
	ax.set_ylabel(r'$y$', fontsize=18)

	if plt_name != None:
		plt.savefig(plt_name,transparent=False)
	else:
		plt.show()
	
	plt.close()

	

def make_pngs(workingDir):
	gridFilePath = workingDir+"/fort.14"
	fort63Path = workingDir+"/fort.63"
	num_elements, num_nodes, coords, bathymetry, Triangles = my_io.read_grid_data(gridFilePath)

	data_array, time_array = read_fort63(fort63Path)
	tri_bath = (bathymetry[Triangles[:,0]] + bathymetry[Triangles[:,1]] + bathymetry[Triangles[:,2]])/3
	[num_vals, num_snaps] = data_array.shape
	num_vals = int(num_vals)
	num_snaps = int(num_snaps)

	pngList = []
	for snap in xrange(num_snaps):
		vals = data_array[:,snap]
		figName = workingDir+"/Ele{}.png".format(snap)

		# read channel values
		# currently only plots one channel
		Chan_time, Chan_x, Chan_y, Chan_z, Chan_ds, Chan_zeta, Chan_height = my_io.read_channels_output(workingDir,snap,0)
		ChanBreadth = 30.0
		Chan_x = Chan_x - ChanBreadth/2
		chan_coords = np.array([Chan_x, Chan_y]).transpose()

		if(abs(Chan_time - time_array[snap,0]) > 1e-5):
			print "Times from fort.63 and the Channels output files don't match. Please make sure they are outputted at the same interval. Exiting now."
			print "Chan_time = ", Chan_time, "DGSWEM time = ", time_array[snap,0]
			os._exit(1)
		
		height = data_array[:,snap] + tri_bath
		plot_hybrid_data(coords, Triangles, height, chan_coords, Chan_ds, Chan_height, chanBreadth=30.0, vmin=0, vmax=1.0, plt_title = "Water Height at time {} s". format(time_array[snap,0]), plt_name=figName)
		pngList.append(figName)

	return pngList


def make_movie(workingDir, pngList):
	clip = mpy.ImageSequenceClip(pngList, fps=8)
	#clip.write_videofile(workingDir+'/Animation.avi',codec='png')
	clip.write_videofile(workingDir+'/Animation.mp4')

def main(argv):
	workingDir = argv[1]
	png_list = make_pngs(workingDir)
	make_movie(workingDir,png_list)

if __name__ == "__main__":
	main(sys.argv)

