import os
import numpy as np
import matplotlib.pyplot as plt
from matplotlib import rc_file

currdir = os.getcwd()
rc_file(currdir+'/my_matplotlib.rc')

#NumFilePath = "/workspace/prapti/results/preliminaryResults/ParkingLot1/OutflowRate.dat"
TrueSolPath="/workspace/prapti/results/preliminaryResults/ParkingLot1/TrueOutflowRate.txt"
#
#NumSol = np.loadtxt(NumFilePath)
TrueSol = np.loadtxt(TrueSolPath)
#
#t_num = NumSol[:,0]
#Qval = NumSol[:,1]
t_true = TrueSol[:,0]
Qtrue = TrueSol[:,1]
#
#fig = plt.figure()
#lines = plt.plot(t_num, Qval, '*', t_true, Qtrue, '-')
#plt.setp(lines[0], color='blue', linewidth = 2.0)
#plt.setp(lines[1], color='magenta', linewidth=2.0)
#plt.legend(lines, [r"DG Solution", r"Analytic Solution"])  
#plt.ylabel(r"Outflow Rate (\text{ft}^2/\textup{min})")
#plt.xlabel(r"Time (min)")
#plt.axis([0,60,0,1.7])

CorrOutflowFilePath = "/workspace/prapti/results/preliminaryResults/ParkingLot1/OutflowRate.dat"
UnCorrOutflowFilePath = "/workspace/prapti/results/preliminaryResults/ParkingLot1/UncorrectedFlowPathOutflowRate.dat"

#TrueSolPath="/workspace/prapti/results/preliminaryResults/ParkingLot1/TrueOutflowRate.txt"
#InfilSolPath = "/workspace/prapti/results/preliminaryResults/ParkingLot1/OutflowRateWithInfiltration.dat"


CorrFlowSol = np.loadtxt(CorrOutflowFilePath)
UncorrFlowSol = np.loadtxt(UnCorrOutflowFilePath)
TrueFlowSol = np.loadtxt(TrueSolPath)

#InfilSol = np.loadtxt(InfilSolPath)

t_num = CorrFlowSol[:,0]
Qval = CorrFlowSol[:,1]
t_num1 = UncorrFlowSol[:,0]
Qval1 = UncorrFlowSol[:,1]

#t_true = TrueFlowSol[:,0]
#Qtrue = TrueFlowSol[:,1]
#t_infil = InfilSol[:,0]
#q_infil = InfilSol[:,1]

#fig = plt.figure()
#lines = plt.plot(t_num1, Qval1, '+', t_num, Qval, '*', t_true, Qtrue, '-')
#plt.setp(lines[0], color='green', linewidth = 2.0)
#plt.setp(lines[1], color='blue', linewidth = 2.0)
#plt.setp(lines[2], color='magenta', linewidth=2.0)
#plt.legend(lines, [r"Approach I", r"Approach II", r"Analytic"], loc=1)  
#plt.ylabel(r"Total Outflow Rate ($\textup{ft}^2/\textup{min}$)")
#plt.xlabel(r"Time (min)")
#plt.axis([0,60,0,1.7])

#fig = plt.figure()
#lines = plt.plot(t_infil, q_infil, '*', t_true, Qtrue, '-')
#plt.setp(lines[0], color = 'blue')
#plt.setp(lines[1], color='magenta')
#plt.legend(lines, [r"Sandy Clay Loam", r"Concrete"])
#plt.ylabel(r'Outflow Rate ($\textup{ft}^2/\textup{min}$)')
#plt.xlabel(r'Time (min)')
#plt.axis([0,60,0,1.7])

CorrTotalFilePath = "/workspace/prapti/results/preliminaryResults/ParkingLot1/CollectedWaterInChannel.dat"
UncorrTotalFilePath = "/workspace/prapti/results/preliminaryResults/ParkingLot1/UncorrectedFlowPathCollectedWaterInChannel.dat"
TrueTotalFilePath="/workspace/prapti/results/preliminaryResults/ParkingLot1/TrueIntegral.txt"

CorrTotalSol = np.loadtxt(CorrTotalFilePath)
UncorrTotalSol = np.loadtxt(UncorrTotalFilePath)
TrueTotalSol = np.loadtxt(TrueTotalFilePath)

t_num = CorrTotalSol[:,0]
CorrTotal = CorrTotalSol[:,1]
t_num1 = UncorrTotalSol[:,0]
UncorrTotal = UncorrTotalSol[:,1]
t_true = TrueTotalSol[:,0]
TrueTotal = TrueTotalSol[:,1]

fig = plt.figure()
lines = plt.plot(t_num1, UncorrTotal,'+', t_num, CorrTotal, '*',  t_true, TrueTotal, '-')
plt.setp(lines[0], color='green', linewidth = 2.0)
plt.setp(lines[1], color='blue', linewidth = 2.0)
plt.setp(lines[2], color='magenta', linewidth=2.0)
plt.legend(lines, [r"Approach I", r"Approach II", r"Analytic"], loc=2)  
plt.ylabel(r"Total Volume ($\textup{ft}^3$)")
plt.xlabel(r"Time (min)")
plt.axis([0,60,0,47])

#plt.show()
plt.tight_layout(pad=0.1)
#fileName="/workspace/prapti/dissertation/Pictures/ParkingLot1OutflowRate.pdf"
#fileName="/workspace/prapti/dissertation/Pictures/AlgorithmIVsAlgorithmIIOutflowRate.pdf"
fileName="/workspace/prapti/dissertation/Pictures/AlgorithmIVsAlgorithmIITotal.pdf"
#fileName="/workspace/prapti/dissertation/Pictures/OutflowRateWithInfiltration.pdf"
plt.savefig(fileName, bbox_inches='tight', transparent=True, pad_inches=0)
plt.close()

