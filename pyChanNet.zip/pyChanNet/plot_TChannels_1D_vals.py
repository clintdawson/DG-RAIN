from plot_channels_and_junctions import read_junctions_grid_file
from plot_channels_and_junctions import read_nodal_junctions_63
from processDataField import interpolate_nodal_values
import numpy as np
import matplotlib.pyplot as plt

workingDir = './TChannels'
grid_file = workingDir + '/TChannelsFloodPlainFinest.14'
DataFilePath = workingDir + '/FloodplainsFinest.63'
ExpFilePath = workingDir + '/ExperimentalData.dat'

# load experimental data set
exp_val = np.loadtxt(ExpFilePath)

triangulation = read_junctions_grid_file(grid_file)
triangulation = triangulation[0]
time_array, Zeta_array = read_nodal_junctions_63(DataFilePath)

# extract the last time snap
Zeta_array = Zeta_array[len(Zeta_array)-1]
# extract the only "junction"
Zeta_array = Zeta_array[0]

width=0.914

#scaled_zeta = [zeta/width for zeta in Zeta_array]

query_x = np.linspace(-7*width, 1*width, num=500)
query_y = [0.5*width for x in query_x]
interp_values = interpolate_nodal_values(triangulation, Zeta_array, query_x, query_y)

scaled_interp_values= [zeta/width for zeta in interp_values]
scaled_query_x = [x/width for x in query_x]

plt.figure()
plt.plot(exp_val[:,0], exp_val[:,1], 'r*', scaled_query_x, scaled_interp_values,'b-' )
#plt.plot(exp_val[:,0]*width, exp_val[:,1]*width, 'r*', query_x, interp_values,'b-' )
plt.show()



