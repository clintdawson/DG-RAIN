import os
import sys
import numpy as np
import matplotlib
import matplotlib.tri as tri
from matplotlib import rc_file
import matplotlib.pyplot as plt
from moviepy.video.io.bindings import mplfig_to_npimage
import moviepy.editor as mpy
import matplotlib.patches as mpatches
from matplotlib.collections import PatchCollection
import re
from my_io import read_grid_data
from plot_watershed import read_channel_nodes_file

def read_kinematic_data_file(path, numEls):
	kin_file = open(path, 'r')
	
	# Read header
	kin_file.readline()
	line = kin_file.readline()
	m = re.search("Total Number of Records = (\d+)", line)
	num_time_snaps = int(m.group(1))

	vals = np.empty((numEls,num_time_snaps))
	time_array = np.empty((num_time_snaps,1))
	for snap in xrange(num_time_snaps):
		header_line = kin_file.readline()
		m = re.search("# Average height at time (\d+\.\d+) in Kinematic Field", header_line)
		time_array[snap] = float(m.group(1))
		for pt in xrange(numEls):
			[elNum, val] = [float(value) for value in kin_file.readline().split()]
			vals[pt, snap] = val
	
	kin_file.close()

	return vals, time_array

def read_floodplain_data_file(path, numEls):
	floodplain_file = open(path, 'r')
	
	# Read header
	floodplain_file.readline()
	line = floodplain_file.readline()
	m = re.search("Total Number of Records = (\d+)", line)
	num_time_snaps = int(m.group(1))

# throw away the next line
	floodplain_file.readline()

	h_vals = np.empty((numEls,num_time_snaps))
	zeta_vals = np.empty((numEls,num_time_snaps))
	
	time_array = np.empty((num_time_snaps,1))
	for snap in xrange(num_time_snaps):
		header_line = floodplain_file.readline()
		m = re.search("# Average H and Zeta at time (\d+\.\d+)", header_line)
		time_array[snap] = float(m.group(1))
		for pt in xrange(numEls):
			[elNum, height, zeta] = [float(value) for value in floodplain_file.readline().split()]
			h_vals[pt, snap] = height
			zeta_vals[pt, snap] = zeta
	
	floodplain_file.close()

	return h_vals, zeta_vals, time_array



def plot_kinfield_data(Coords, triangles, height, vmin, vmax, ChannelNodesFile=None, plt_title=None, plt_name=None):
	
	currdir = os.getcwd()
	rc_file(currdir+'/my_matplotlib.rc')
	triangulation = tri.Triangulation(Coords[:,0],Coords[:,1],triangles=triangles)
	fig  = plt.figure()
	ax = plt.subplot(1,1,1)
# adjust ticks on the x-axis
	ax.locator_params(axis='x', nbins=3)
	plt.gca().set_aspect('equal')
	cmap = plt.get_cmap('jet')

	plt.tripcolor(triangulation, facecolors=height, edgecolors='w',vmin=vmin, vmax=vmax, cmap=cmap)
	
	if(ChannelNodesFile):
		NodeList = read_channel_nodes_file(ChannelNodesFile)
		plt.plot(Coords[NodeList,0], Coords[NodeList,1], marker='o', color='r', ls='None')
			
	plt.colorbar()
	
	if (plt_title != None):
			ax.set_title(plt_title)
				
	ax.set_xlabel(r'$x$', fontsize=18)
	ax.set_ylabel(r'$y$', fontsize=18)

	if plt_name != None:
		plt.savefig(plt_name,transparent=False)
	else:
		plt.show()
	
	plt.close()

def make_pngs(workingDir):
	WatershedFilePath = workingDir+"/Floodplains.14"
	dataFilePath = workingDir+"/KinField.63"
	#dataFilePath = workingDir+"/Floodplains.63"
	ChannelNodesFile = workingDir+"/ChannelNodes.in"
	
	[num_elements, num_nodes, coords, depth, triangles] = read_grid_data(WatershedFilePath)
	[data_array, time_array] = read_kinematic_data_file(dataFilePath, num_elements)
	#[H_array, zeta_array, time_array] = read_floodplain_data_file(dataFilePath, num_elements)
	#data_array = H_array

	[num_vals, num_snaps] = data_array.shape
	num_vals = int(num_vals)
	num_snaps = int(num_snaps)

	vmin = np.amin(data_array);
	#vmax = 10.0
	vmax = np.amax(data_array);
	#print "vmin = ", vmin, " vmax = ", vmax

	pngList = []
	for snap in xrange(num_snaps):
		height = data_array[:,snap]
		figName = workingDir+"/KinematicFieldHeight{}.png".format(snap)
		#figName = workingDir+"/FloodplainHeight{}.png".format(snap)

		plot_kinfield_data(coords, triangles, height, vmin, vmax,ChannelNodesFile=ChannelNodesFile, plt_title="Water height at time {} s".format(time_array[snap,0]), plt_name=figName)

		pngList.append(figName)

	return pngList


def make_movie(workingDir, pngList):
	clip = mpy.ImageSequenceClip(pngList, fps=4)
	#clip.write_videofile(workingDir+'/FloodplainAnimation.avi',codec='png')
	clip.write_videofile(workingDir+'/KinematicFieldAnimation.mp4')

def main(argv):
	workingDir = argv[1]
	png_list = make_pngs(workingDir)
	make_movie(workingDir,png_list)

if __name__ == "__main__":
	main(sys.argv)

