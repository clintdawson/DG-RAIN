import os
import numpy as np
import matplotlib.pyplot as plt
from matplotlib import rc_file

HalfPeriodVelPath = "/h2/prapti/workrepo/ChannelNetwork/1DCode/Tests/ParabolicBowl/NumVelocityHalfPeriod"
ThreePeriodsVelPath = "/h2/prapti/workrepo/ChannelNetwork/1DCode/Tests/ParabolicBowl/NumVelocityThreePeriods"

HalfPeriodSol = np.loadtxt(HalfPeriodVelPath)
ThreePeriodsSol = np.loadtxt(ThreePeriodsVelPath)

x_coord = HalfPeriodSol[:,0]
HalfPeriodVal = HalfPeriodSol[:,1]
ThreePeriodsVal = ThreePeriodsSol[:,1]
AnalyticalSol = np.zeros(x_coord.shape)

currdir = os.getcwd()
rc_file(currdir+'/my_matplotlib.rc')
fig = plt.figure()
lines=plt.plot(x_coord, HalfPeriodVal, '.',x_coord, AnalyticalSol)
plt.setp(lines[0], color='magenta')
plt.setp(lines[1], color='blue', linewidth=2)
plt.legend(lines, [r"DG Solution", r"Analytical Solution"])
plt.ylabel('Velocity')
plt.xlabel('x')
plt.axis([0,4,-0.1,0.1])
#plt.show()
plt.tight_layout(pad=0.1)
fileName='/workspace/prapti/Dropbox/ChannelNetworksPaper/Pictures/HalfPeriodVelocity1D.pdf'
plt.savefig(fileName, bbox_inches='tight', transparent=True, pad_inches=0)
plt.close()


fig2 = plt.figure()
lines = plt.plot(x_coord, ThreePeriodsVal, '.', x_coord, AnalyticalSol)
plt.setp(lines[0], color='magenta')
plt.setp(lines[1], color='blue', linewidth=2)
plt.legend(lines, [r"DG Solution", r"Analytical Solution"])
plt.ylabel("Velocity")
plt.xlabel("x")
plt.axis([0,4,-0.1, 0.1])
#plt.show()
plt.tight_layout(pad=0.1)
fileName='/workspace/prapti/Dropbox/ChannelNetworksPaper/Pictures/ThreePeriodsVelocity1D.pdf'
plt.savefig(fileName, bbox_inches='tight', transparent=True, pad_inches=0)
plt.close()

