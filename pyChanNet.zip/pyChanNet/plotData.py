import os
import math
import numpy as np
import matplotlib
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import matplotlib.tri as tri
from matplotlib import rc_file
#from matplotlib import rcParams
from matplotlib import cm
#from matplotlib.font_manager import FontProperties

r"""
def set_font_properties():
	rcParams['axes.labelsize'] = 12
	rcParams['xtick.labelsize'] = 12
	rcParams['ytick.labelsize'] = 12
	rcParams['legend.fontsize'] = 12
	
	rcParams['font.family'] = 'serif'
	rcParams['font.serif'] = ['Computer Modern Roman']
"""

def plot1D(coord0, data_field0, coord1=None, data_field1=None, coord2=None, data_field2=None,plotName=None,figTitle0='DG Solution', figTitle1 = 'Analytical Solution', figTitle2 = 'Bottom Elevation', xlabel='x', ylabel='Water Height'):
#def plot1D(coord, data_field, xcoordAnalyticSol=None, analyticSol=None, bathymetryCoord= None, bathymetry=None,plotName=None):
	r""" Function to make and save plots of 1D data file. 
	Also plots the bathymetry and the analytical solution on the same graph if provided

	Input: 
	- coord : arry containing 1D x-coord corresponding to the DG solution provided
	- data_field: array of DG solution for the field we want to plot (usually Zeta, H or Q)
	- xcoordAnalyticSol: array containing the x values at which the analytic solution is provided
	- data_field1: array of analytic solution (obtained from SWASHES)
	- data_field2: data_field2 values corresponding to the xcoord values in coord
	- plotName: full name (including the path and extension) for the plot we want to create and save

	Output:
	- If plotName not provided, then just displays the picture on the screen
	
	"""
	currdir = os.getcwd()
	rc_file(currdir+'/my_matplotlib.rc')
	fig = plt.figure()
	if (data_field2 != None):
		if (data_field1 !=None):
			if (coord2 != None):
				lines=plt.plot(coord2, data_field2, coord1, data_field1,coord0, data_field0,'--')
			else:
				lines=plt.plot(coord0, data_field2, coord1, data_field1, coord0, data_field0,'--')	
			plt.setp(lines[0], color='red', linewidth = 2.0)
			plt.setp(lines[1], color='blue', linewidth = 2.0)
			plt.setp(lines[2], color='magenta', linewidth = 2.75)
			plt.legend(lines,[figTitle2,figTitle1, figTitle0])
		else:
			lines=plt.plot(coord0, data_field2, coord0, data_field0,'--') 
			plt.setp(lines[0], color='red', linewidth = 2.0)
			plt.setp(lines[1], color='magenta', linewidth = 2.75)
			plt.legend(lines,[figTitle2, figTitle0])
	else:
		if (data_field1 != None):
			lines=plt.plot(coord1, data_field1, coord0, data_field0, '--')
			plt.setp(lines[0], color='blue', linewidth=2.0)
			plt.setp(lines[1], color='magenta', linewidth=2.75)
			plt.legend(lines,[figTitle1, figTitle0])
		else:
			lines=plt.plot(coord0, data_field0)
			plt.setp(lines, color='magenta',linewidth = 2.75)
			#plt.legend(lines,['figTitle0'])
		
	plt.ylabel(ylabel)
	plt.xlabel(xlabel)
	plt.axis([0,10,0,0.006])
	if plotName != None:
		#rcParams['text.usetex'] = True
		plt.tight_layout(pad=0.1)
		plt.savefig(plotName, bbox_inches='tight', transparent=True, pad_inches=0)
	else:
		plt.show()
	plt.close()	


def plot2D(coords, bathymetry, trianglesArray, data_field=None, data_field_format=None, plotName=None, meshName=None):
	currdir = os.getcwd()
	rc_file(currdir+'/my_matplotlib.rc')
	triangulation = tri.Triangulation(coords[:,0],coords[:,1],triangles=trianglesArray)
	#triangulation = tri.Triangulation(coords[:,0],coords[:,1],triangles=trianglesArray)
	fig  = plt.figure()
	ax = plt.subplot(1,1,1)	
	plt.gca().set_aspect('equal')
	if data_field == None:
		#maxval = np.amax(bathymetry)
		#minval = np.amin(bathymetry)
		#maxval = 0.0001
		#minval = -0.04
		#print "maxval = ", maxval, "minval = ", minval 
		#contourNum = math.floor((maxval-minval)/0.01)
		#contourLevels = np.linspace(minval,maxval,num=contourNum)
		#plt.triplot(triangulation, 'g-')	
		plt.tripcolor(triangulation, bathymetry, shading='gourad')	
		#plt.tricontourf(triangulation, bathymetry, levels=contourLevels)	
		#plt.axis([-11, 12, -10, 1])
		#box = ax.get_position()
		#axColor = plt.axes([box.x0+1.05*box.width, box.y0+0.25*box.height, 0.01, 0.5*box.height]) 
		#plt.colorbar(cax=axColor,orientation='vertical')

		ax.set_xlabel(r'$x$', fontsize=18)
		ax.set_ylabel(r'$y$', fontsize=18)
		if meshName == None:
			plt.show()
		else:
			plt.savefig(meshName, bbox_inches='tight', transparent=True, pad_inches=0)
	
	else:
	
		cmap = plt.get_cmap('jet')
		if (data_field != None):
			if (data_field_format == 'contour'):
				maxVal = np.amax(data_field)
				minVal = np.amin(data_field)
				#maxVal = 0.75;
				#minVal = -3.0;
				#contourNum=15;
				contourNum = math.floor((maxVal-minVal)/0.1)
				
				contourLevels = np.linspace(minVal,maxVal,num=contourNum)
				#colorBarTicks = np.empty((contourNum/2 +1,1))
				#i = 0
				#j = 0
				#while i < contourNum:
				#	colorBarTicks[j] = contourLevels[i]
				#	i += 2
				#	j += 1
				#if colorBarTicks[j-1] != contourLevels[contourNum-1]:
				#	colorBarTicks[j] = contourLevels[contourNum-1]
				#colorBarTicks =[-3.0,-2.5,-2.0,-1.5,-1.0,-0.5,0.0,0.5]
				colorBarTickNum= 8
				colorBarTicks = np.linspace(minVal,maxVal,num=colorBarTickNum)
				plt.tricontourf(triangulation, data_field, levels=contourLevels)
				#plt.tricontourf(triangulation, data_field)
			else:
				plt.tripcolor(triangulation, data_field, shading='gouraud')
	
		plt.axis([-7, 1, -1, 1])
		#plt.axis([-11, 12, -10, 1])
		#plt.axis([600, 635, -15, 10])
		
		box = ax.get_position()
		#axColor = plt.axes([box.x0+1.02*box.width, box.y0+0.05, 0.015,0.85*box.height]) 
		axColor = plt.axes([box.x0+0.1*box.width, 0.9*box.height, 0.8*box.width, 0.02]) 
		if data_field_format == 'contour' :
			#plt.colorbar(cax = axColor,orientation="vertical", format="%.3f")
			#plt.colorbar(cax = axColor,orientation="horizontal")
			plt.colorbar(cax = axColor, ticks = colorBarTicks, orientation="horizontal")
		else:
			plt.colorbar(cax = axColor, orientation="vertical")
			#plt.colorbar(cax = axColor, orientation="horizontal")
		#ax.set_xlabel(r'$x^*$', fontsize=18)
		#ax.set_ylabel(r'$y^*$', fontsize=18)
		
		ax.set_xlabel(r'$x^*$', fontsize=18)
		ax.set_ylabel(r'$y^*$', fontsize=18)
		
		if plotName != None:
			plt.savefig(plotName, bbox_inches='tight', transparent=True, pad_inches=0)
		else:
			plt.show()
	
	plt.close()

def plot2DNormal(coords, bathymetry, trianglesArray, data_field=None, data_field_format=None, plotName=None, meshName=None, transparence_flag=True, plt_title=None,vmin=None, vmax=None):
	currdir = os.getcwd()
	rc_file(currdir+'/my_matplotlib.rc')
	triangulation = tri.Triangulation(coords[:,0],coords[:,1],triangles=trianglesArray)
	fig  = plt.figure()
	ax = plt.subplot(1,1,1)	
	plt.gca().set_aspect('equal')
	if data_field == None:
		#plt.tricontour(triangulation, bathymetry)	
		plt.triplot(triangulation, 'g-')	
		plt.xlabel('x (m)', fontsize=18)
		plt.ylabel('y (m)', fontsize=18)
		plt.axis([-600,600,-1200,600])	
		#x = coords[:,0];
		#y = coords[:,1];
		#z = bathymetry

		#ax = fig.gca(projection='3d')

		#ax.plot_trisurf(x, y, bathymetry, lw=0.2, edgecolor="black", color="grey", alpha= 0.75)
		##ax.plot_trisurf(triangulation, bathymetry, lw=0.2, edgecolor="black", color="grey", alpha= 0.75)
		##ax.plot_trisurf(triangulation, bathymetry, lw=0.2 )
		#
		#ax.set_xlabel(r'$x$', fontsize=18)
		#ax.set_ylabel(r'$y$', fontsize=18)
		#ax.set_zlabel(r'$Topography$', fontsize=18)

		plt.locator_params(axis = 'x', nbins=5)
		plt.locator_params(axis = 'y', nbins=8)
		#plt.locator_params(axis = 'z', nbins=4)
		
		if meshName == None:
			plt.show()
		else:
			plt.savefig(meshName, bbox_inches='tight', transparent =transparence_flag, pad_inches=0)
	
	else:
		if (data_field_format == 'contour'):
			maxVal = np.amax(data_field)
			minVal = np.amin(data_field)
			contourNum = math.floor((maxVal-minVal)/0.1)
			contourLevels = np.linspace(minVal,maxVal,num=contourNum)
			colorBarTickNum= 8
			colorBarTicks = np.linspace(minVal,maxVal,num=colorBarTickNum)
			plt.tricontourf(triangulation, data_field, levels=contourLevels)
		else:
			plt.tripcolor(triangulation, facecolors=data_field, edgecolors='w',vmin=vmin, vmax=vmax)
			#colorBarTickNum = 10
			#colorBarTicks = np.linspace(0,0.3,num=colorBarTickNum)
			if (plt_title != None):
				ax.set_title(plt_title)
				
			plt.colorbar()
			#plt.axis([-7,1,-1,1.5])
			#plt.axis([-610,610,-1250,650])
			plt.locator_params(axis='x', nbins=5)
			plt.locator_params(axis='y', nbins=5)

		ax.set_xlabel(r'$x$', fontsize=18)
		ax.set_ylabel(r'$y$', fontsize=18)
		
		if plotName != None:
			plt.savefig(plotName, transparent=transparence_flag)
		else:
			plt.show()
	
	plt.close()
