import os
import numpy as np
from math import log10 as log
import matplotlib.pyplot as plt
from matplotlib import rc_file

NumMidPoints=np.array([50.,100.,200.,500.,1000.]);
ZetaError = np.array([0.0062, 0.0029, 0.0014, 0.0006, 0.0003])

currdir = os.getcwd()
rc_file(currdir+'/my_matplotlib.rc')
fig = plt.figure()
lines = plt.loglog(NumMidPoints, ZetaError, NumMidPoints, (0.2)*NumMidPoints**(-1))
plt.axis([10,10**(3.4),10**(-4),10**(-2)])
plt.setp(lines[0], color='red', linewidth=1.5, marker='o', linestyle='--')
plt.setp(lines[1], color = 'blue', linewidth=1.5)
plt.xlabel('N')
plt.ylabel(r"$L^{\infty}$ Error")
plt.legend(lines,['Water Surface Slope', 'Line with slope -1'])
#plt.show()

plt.tight_layout(pad=0.1)
plt.savefig('ZetaErrorRoeFlux2D.png', bbox_inches='tight', transparent=True, pad_inches=0)
plt.savefig('ZetaErrorRoeFlux2D.pdf', bbox_inches='tight', transparent=True, pad_inches=0)
