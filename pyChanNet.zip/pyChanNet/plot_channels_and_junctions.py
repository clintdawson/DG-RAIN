import os
import sys
import numpy as np
from math import sqrt, atan, atan2, sin, cos, pi, floor
import re
import matplotlib
import matplotlib.tri as tri
from matplotlib import rc_file
import matplotlib.pyplot as plt
from moviepy.video.io.bindings import mplfig_to_npimage
import moviepy.editor as mpy
import matplotlib.patches as mpatches
from matplotlib.path import Path
from matplotlib.collections import PolyCollection
from matplotlib.collections import PatchCollection
import my_io
#from processDataField import interpolate_nodal_values

# make a rectangular box around the line connecting (x1,y1)
# and (x2,y2) by finding points that lie on the line 
# perpendicular to this line
def make_rect_nodes(x1,x2,y1,y2,b1,b2):
	b1 = 5*b1
	b2 = 5*b2
	rect_box = []

	norm_vec = [-(y2-y1), x2-x1]
	vec_len = sqrt((y2-y1)*(y2-y1) + (x2-x1)*(x2-x1))
	norm_vec[0] = norm_vec[0]/vec_len
	norm_vec[1] = norm_vec[1]/vec_len

	rect_box.append((x1+0.5*b1*norm_vec[0] , y1+0.5*b1*norm_vec[1]))
	rect_box.append((x1-0.5*b1*norm_vec[0] , y1-0.5*b1*norm_vec[1]))
	rect_box.append((x2+0.5*b2*norm_vec[0] , y2+0.5*b2*norm_vec[1]))
	rect_box.append((x2-0.5*b2*norm_vec[0] , y2-0.5*b2*norm_vec[1]))

	return rect_box

def sort_counterclockwise_order(rect_box):
	xcenter = 0.25*(rect_box[0][0] + rect_box[1][0] + rect_box[2][0] + rect_box[3][0])
	ycenter = 0.25*(rect_box[0][1] + rect_box[1][1] + rect_box[2][1] + rect_box[3][1])
	angleList = []
	vertDict = {}
	for vertex in rect_box:
		x = vertex[0]
		y = vertex[1]
		angle = atan2(y-ycenter,x-xcenter)
		angleList.append(angle)
		vertDict[angle] = vertex

	angleList = sorted(angleList)
	sortedVertices = []
	for key in angleList:
		sortedVertices.append(vertDict[key])

	sortedVertices.append(sortedVertices[0])
	return sortedVertices

def read_channels_grid_file(path):
	channels_file = open(path, 'r')
	
	# Read number of channels
	line = channels_file.readline()
	NumChannels = int(line)
	RectangularBoxes = []
	for ch in xrange(NumChannels):
	# read numnodes
		NumNodes = int(channels_file.readline())
		ch_x = []
		ch_y = []
		ch_b = []
		for n in xrange(NumNodes):
			[x, y, z, b, m1, m2, n] = [float(value) for value in channels_file.readline().split()]
			ch_x.append(x)
			ch_y.append(y)
			ch_b.append(b)
		for el in xrange(NumNodes-1):
			x1 = ch_x[el]
			y1 = ch_y[el]
			x2 = ch_x[el+1]
			y2 = ch_y[el+1]
			rect_box = make_rect_nodes(ch_x[el], ch_x[el+1], ch_y[el], ch_y[el+1], ch_b[el],ch_b[el+1])
			rect_box = sort_counterclockwise_order(rect_box)

			RectangularBoxes.append(rect_box)

	return RectangularBoxes

def read_junctions_grid_file(path):
	junctions_file = open(path, 'r')

	# Read number of junctions
	NumJunctions = int(junctions_file.readline())
	triangulationArray = []
	for i in xrange(NumJunctions):
		[NumEls, NumNodes] = [int(value) for value in junctions_file.readline().split()]
		x = []
		y = []
		trianglesArray = np.empty((NumEls,3), dtype='int32')

		# Read in coordinates of each node
		for n in xrange(NumNodes):
			line = junctions_file.readline().split()
			x.append(float(line[1]))
			y.append(float(line[2]))
			x[n] = x[n]
			y[n] = y[n]

		# Read in triangles
		for t in xrange(NumEls):
			line = junctions_file.readline().split()
			trianglesArray[t,0] = int(line[2])-1
			trianglesArray[t,1] = int(line[3])-1
			trianglesArray[t,2] = int(line[4])-1

		triangulation = tri.Triangulation(x,y,triangles=trianglesArray)
		triangulationArray.append(triangulation)

		#matchstring = "Number of Junction Edges Connected to Channels = (\d+)"
		line = junctions_file.readline()
		#m = re.search(matchstring, line)
		#numConnEdges = int(m.group(1))
		numConnEdges = int(line)
		for edg in xrange(numConnEdges):
			junctions_file.readline()
	
	return triangulationArray

# assumes linear elements were used
def read_channels_63(path):
	channels_file = open(path, 'r')

	# Read header
	channels_file.readline()

	# Read number of records
	line = channels_file.readline()
	m = re.search("Total Number of Records = (\d+)", line)
	num_snaps = int(m.group(1))
	line = channels_file.readline()
	m = re.search("Number of Channels = (\d+)", line)
	NumChannels = int(m.group(1))
	NumElsArr = []
	HVals_array = []
	ZetaVals_array = []


	time_array = np.empty((num_snaps,1))
	
	# Loop to extract the number of nodes for each channel
	for i in xrange(NumChannels):
		line = channels_file.readline()
		matchstring = "Number of data points for channel {} = (\d+)".format(i)
		m = re.search(matchstring, line)
		NumElsArr.append(int(m.group(1))/2)
	
	# Loop to extract the data points
	for i in xrange(num_snaps):
		CT_H_Arr = []
		CT_Zeta_Arr = []
		for ch in xrange(NumChannels):
			matchstring = "# H and Zeta at time (\d+\.\d+) for Channel {}".format(ch)
			line = channels_file.readline()
			m = re.search(matchstring, line)
			time = float(m.group(1))
			time_array[i,0] = time
			for el in xrange(NumElsArr[ch]):
				[H1, Zeta1] =[float(value) for value in channels_file.readline().split()]
				[H2, Zeta2] =[float(value) for value in channels_file.readline().split()]	
				H_avg = 0.5*(H1+H2)
				Zeta_avg = 0.5*(Zeta1+Zeta2)
				CT_H_Arr.append(H_avg)
				CT_Zeta_Arr.append(Zeta_avg)
		
		HVals_array.append(CT_H_Arr)
		ZetaVals_array.append(CT_Zeta_Arr)
	
	return HVals_array, ZetaVals_array

#def read_nodal_junctions_63(path):
#	junctions_file = open(path, 'r')
#
#	# Read header
#	junctions_file.readline()
#
#	# Read number of records
#	line = junctions_file.readline()
#	m = re.search("Total Number of Records = (\d+)", line)
#	num_snaps = int(m.group(1))
#	line = junctions_file.readline()
#	m = re.search("Number of Floodplains = (\d+)", line)
#	#m = re.search("Number of Junctions = (\d+)", line)
#	NumJunctions = int(m.group(1))
#	NumNodesArr = []
#	#HVals_array = []
#	ZetaVals_array = []
#	
#	time_array = np.empty((num_snaps,1))
#	
#	# Loop to extract the number of nodes for each channel
#	for i in xrange(NumJunctions):
#		line = junctions_file.readline()
#		matchstring = "Number of data points for junction {} = (\d+)".format(i)
#		m = re.search(matchstring, line)
#		NumNodesArr.append(int(m.group(1)))
#	
#	# Loop to extract the data points
#	for i in xrange(num_snaps):
#		#J_H_Arr = []
#		J_Zeta_Arr = []
#		for j in xrange(NumJunctions):
#			new_H = []
#			new_Zeta = []
#			matchstring = "# Average H and Zeta at time (\d+\.\d+) for Junction {}".format(j)
#			#matchstring = "# Nodal H at time (\d+\.\d+) for Junction {}".format(j)
#			line = junctions_file.readline()
#			m = re.search(matchstring, line)
#			time = float(m.group(1))
#			time_array[i,0] = time
#			for el in xrange(NumNodesArr[j]):
#				[nodeNum, H, Zeta] =[float(value) for value in junctions_file.readline().split()]
#				#new_H.append(H)
#				new_Zeta.append(Zeta)
#			
#			#J_H_Arr.append(new_H)
#			J_Zeta_Arr.append(new_Zeta)
#
#		#HVals_array.append(J_H_Arr)
#		ZetaVals_array.append(J_Zeta_Arr)
#	
#	return time_array, ZetaVals_array
#	#return time_array, HVals_array, ZetaVals_array


def read_junctions_63(path):
	junctions_file = open(path, 'r')

	# Read header
	junctions_file.readline()

	# Read number of records
	line = junctions_file.readline()
	m = re.search("Total Number of Records = (\d+)", line)
	num_snaps = int(m.group(1))
	line = junctions_file.readline()
	#m = re.search("Number of Floodplains = (\d+)", line)
	m = re.search("Number of Junctions = (\d+)", line)
	NumJunctions = int(m.group(1))
	NumElsArr = []
	HVals_array = []
	ZetaVals_array = []
	
	time_array = np.empty((num_snaps,1))
	
	# Loop to extract the number of nodes for each channel
	for i in xrange(NumJunctions):
		line = junctions_file.readline()
		matchstring = "Number of data points for junction {} = (\d+)".format(i)
		m = re.search(matchstring, line)
		NumElsArr.append(int(m.group(1)))
	
	# Loop to extract the data points
	for i in xrange(num_snaps):
		J_H_Arr = []
		J_Zeta_Arr = []
		for j in xrange(NumJunctions):
			new_H = []
			new_Zeta = []
			matchstring = "# Average H and Zeta at time (\d+\.\d+) for Junction {}".format(j)
			#matchstring = "# Nodal H at time (\d+\.\d+) for Junction {}".format(j)
			line = junctions_file.readline()
			m = re.search(matchstring, line)
			time = float(m.group(1))
			time_array[i,0] = time
			for el in xrange(NumElsArr[j]):
				[elNum, H, Zeta] =[float(value) for value in junctions_file.readline().split()]
				new_H.append(H)
				new_Zeta.append(Zeta)
			
			J_H_Arr.append(new_H)
			J_Zeta_Arr.append(new_Zeta)

		HVals_array.append(J_H_Arr)
		ZetaVals_array.append(J_Zeta_Arr)
	
	return time_array, HVals_array, ZetaVals_array

def plot_junction_data(triangulationList, dataFieldList, vmin=None, vmax=None, plt_title=None, plt_name=None):
	currdir = os.getcwd()
	rc_file(currdir+'/my_matplotlib.rc')

# plot junctions data
	num_junctions = len(triangulationList)

	fig, axes = plt.subplots(nrows=num_junctions, ncols=1, sharex=True)
	cmap = plt.get_cmap('jet')
	
	for j in xrange(num_junctions):
		if num_junctions > 1:
			ax = axes.flat[j]
		else:
			ax = axes
		triangulation = triangulationList[j]
		data_field = np.array(dataFieldList[j])
		
		#plt.gca().set_aspect('equal')
		im = ax.tripcolor(triangulation, facecolors=data_field, edgecolors='w',vmin=vmin, vmax=vmax, cmap=cmap)
		#contourNum = 10
		#contourLevels = np.linspace(vmin, vmax, num=contourNum)
		#plt.tricontourf(triangulation, data_field, levels=contourLevels) 
		#plt.tricontourf(triangulation, data_field) 
		#plt.tripcolor(triangulation, facecolors=data_field, edgecolors='w',vmin=vmin, vmax=vmax, cmap=cmap)
		
		# format the axes
		#ax.set_xlim(-15,15)
		#ax.set_ylabel(r'$y$', fontsize=18)

	
		# adjust ticks on the x-axis
		#if (j == 0):
		#	ax.locator_params(axis='x', nbins=5)
		#if (j == 1):
		#	ax.set_xlabel(r'$x$', fontsize=16)
		#	ax.locator_params(axis='x', nbins=5)

	if num_junctions > 1:
		cax, kw = matplotlib.colorbar.make_axes([ax for ax in axes.flat])
		plt.colorbar(im, cax=cax, **kw)
	else:
		plt.colorbar(im, cax=axes)

	#plt.colorbar()	
	if (plt_title):
		plt.suptitle(plt_title, fontsize=20)
	if (plt_name):
		plt.savefig(plt_name, transparent=False)
	else:
		plt.show()

	#plt.show()

def plot_hybrid_data(triangulationList, dataFieldList, Rect_Boxes, DataBoxesVals, vmin=None, vmax=None, plt_title=None, plt_name=None):
	currdir = os.getcwd()
	rc_file(currdir+'/my_matplotlib.rc')

	fig = plt.figure()
	ax = plt.subplot(1,1,1)

	ax.set_xlim(-80,80)
	ax.set_ylim(0,400)
	#ax.set_aspect('equal')
	#ax.set_aspect(1./ax.get_data_ratio())
	ax.locator_params(axis='x', nbins=3)
	cmap = plt.get_cmap('jet')
	

	# plot junctions data
	num_junctions = len(triangulationList)
	for j in xrange(num_junctions):
		triangulation = triangulationList[j]
		data_field = np.array(dataFieldList[j])
		plt.tripcolor(triangulation, facecolors=data_field, edgecolors='w',vmin=vmin, vmax=vmax, cmap=cmap)
	
	# plot chanels data
	codes = [Path.MOVETO, Path.LINETO, Path.LINETO, Path.LINETO, Path.CLOSEPOLY,]
	patches = []
	for verts in Rect_Boxes:
		path = Path(verts, codes)
		patch = mpatches.PathPatch(path, lw=2)
		patches.append(patch)

	Channels = PatchCollection(patches, cmap=cmap, alpha=1.0)
	Channels.set_array(np.array(DataBoxesVals))
	Channels.set_clim([vmin, vmax])
	ax.add_collection(Channels)	
	plt.colorbar()

	if (plt_title):
		plt.title(plt_title, y=1.05, fontsize=20)
	if (plt_name):
		plt.savefig(plt_name, transparent=False)
	else:
		plt.show()

	#plt.show()

	plt.close()


def make_pngs(workingDir):
	pngList = []

	ChannelsGridFilePath = workingDir+"/Channels.14"
	JunctionsGridFilePath = workingDir+"/Junctions.14"
	#JunctionsGridFilePath = workingDir+"/TChannelsFloodPlainFinest.14"

	# read in the grid files
	rectangularBoxes = read_channels_grid_file(ChannelsGridFilePath)
	triangulationArray = read_junctions_grid_file(JunctionsGridFilePath)

	ChannelsDataFilePath = workingDir+"/Channels.63"
	JunctionsDataFilePath = workingDir+"/Junctions.63"
	#JunctionsDataFilePath = workingDir + "/FloodplainsFinest.63"

	Channels_H_array, Channels_Zeta_array = read_channels_63(ChannelsDataFilePath)
	time_array, Junctions_H_array, Junctions_Zeta_array = read_junctions_63(JunctionsDataFilePath)
	
	#time_array, Junctions_Zeta_array = read_nodal_junctions_63(JunctionsDataFilePath)
	
	time_array = np.around(time_array, decimals=1)

	num_snaps= len(Junctions_Zeta_array)
	num_snaps = int(num_snaps)

	vmin = -0.0011856
	vmax = 10.029767
	
	#vmin=np.amin(np.amin(Junctions_Zeta_array))
	#vmax=np.amax(np.amax(Junctions_Zeta_array))
	#vmin_ch = np.amin(Channels_Zeta_array)
	#vmax_ch = np.amax(Channels_Zeta_array)

	#vmin = min(vmin, vmin_ch)
	#vmax = max(vmax, vmax_ch)


	for snap in xrange(num_snaps):
		title = "Water surface elevation at time {} s".format(time_array[snap,0])
		figName = workingDir+"/Elevation_ChannelNetworkEnlarged{}.png".format(snap)
		Junctions_H = Junctions_H_array[snap]
		Channels_H = Channels_H_array[snap]

		#plot_junction_data(triangulationArray, Junctions_Zeta_array[snap], plt_title=title, plt_name=figName)
		#plot_junction_data(triangulationArray, Junctions_Zeta_array[snap], vmin=vmin, vmax=vmax, plt_title=title, plt_name=figName)
		plot_hybrid_data(triangulationArray, Junctions_Zeta_array[snap],rectangularBoxes, Channels_Zeta_array[snap], vmin=vmin, vmax=vmax, plt_title=title, plt_name=figName)
		pngList.append(figName)
	
	#vmin = np.amin(Junctions_Zeta_array[num_snaps-1])
	#vmax = np.amax(Junctions_Zeta_array[num_snaps-1])
	#print "vmin = ", vmin, "vmax = ", vmax
	#figName = workingDir+"/AvgElevationFinest.png"
	#plot_junction_data(triangulationArray, Junctions_Zeta_array[num_snaps-1], vmin=vmin, vmax=vmax, plt_name=figName)
	
	return pngList


def make_movie(workingDir, pngList):
	clip = mpy.ImageSequenceClip(pngList, fps=4)
	#clip.write_videofile(workingDir+'/TChannelsElevation.mp4')
	#clip.write_videofile(workingDir+'/Junctions.avi', codec='png')
	#clip.write_videofile(workingDir+'/ChannelNetwork.avi', codec='png')
	clip.write_videofile(workingDir+'/ChannelNetworkEnlarged.mp4')

def main():
	workingDir = 'DGSHEDFullWatershedFlooding'
	png_list = make_pngs(workingDir)
	make_movie(workingDir, png_list)

if __name__=="__main__":
	main()

