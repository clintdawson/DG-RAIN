# Data reading functions for ChannelNetwork data

import logging
import math
import numpy as np
import re

def file_len(fname):
    r"""Find number of lines in a file *fname*"""
    with open(fname) as f:
        for i, l in enumerate(f):
            pass
    return i + 1


def read_grid_data(path):
    r"""
    Read a grid specification file (fort.14)

    :Note: This function currently only reads in the grid itself and not the 
           boundary specifications.

    :Input:
     - *path* (string) - Path to grid data file.

    :Output:
     - (numpy.ndarray(num_nodes, 2)) - Coordinates of each node.
     - (numpy.ndarray(num_nodes)) - Array containing depths at each node.
     - (numpy.ndarray(num_elements, 3)) - Numpy array containg specifcation of 
       each element's nodal points in counter-clockwise fashion.
    """

    grid_file = open(path, 'r')

    # Read header
    grid_file.readline()
    num_elements, num_nodes = [int(value) for value in grid_file.readline().split()]
    
    # Create necessary array storage
    coords = np.empty((num_nodes,2))
    depth = np.empty((num_nodes))
    triangles = np.empty((num_elements,3),dtype='int32')

    # Read in coordinates of each node
    logging.info("Reading coordinates and depths of each node...")
    for n in xrange(num_nodes):
        line = grid_file.readline().split()
        coords[n,0] = float(line[1])
        coords[n,1] = float(line[2])
        depth[n] = float(line[3])

    # Read in triangles
    logging.info("Reading in elements...")
    for n in xrange(num_elements):
        line = grid_file.readline().split()
        # Construct triangles
        triangles[n,0] = int(line[2]) - 1
        triangles[n,1] = int(line[3]) - 1
        triangles[n,2] = int(line[4]) - 1
    # Read in boundary data
    #logging.warning("Boundary data reading has not been implemented, continuing.")

    grid_file.close()

    return num_elements, num_nodes, coords, depth, triangles

def return_plotCoord_and_data(path, num_nodes, read_zeta=False):
	r"""
	Read ChannelNetwork 1D data files
	"""

	plot_coord = np.empty((num_nodes,1))
	data_field1 = np.empty((num_nodes,1))
	data_field2 = np.empty((num_nodes,1))
	z = np.empty((num_nodes,1))

	data_file = open(path, 'r')	
	data_file.readline()
	data_file.readline()
	x0 = 0
	y0 = 0
	for i in range(num_nodes):
		array = map(float,data_file.readline().split())
		xcoord = array[0]
		ycoord = array[1]
		z[i]=(array[2])
		if i == 0:
			x0 = xcoord
			y0 = ycoord

		plot_coord[i] = math.sqrt((xcoord-x0)**2+(ycoord-y0)**2) 

		if read_zeta:
			val1 = array[4]
		else:
			val1 = array[3]

		array = map(float,data_file.readline().split())
	   
		if read_zeta:
			val2 = array[4]
		else:
			val2 = array[3]

		data_field1[i]=val1
		data_field2[i]=val2

	data_file.close()
	
	#return plot_coord, data_field1, z
	return plot_coord, data_field1, data_field2, z


def read_data_file(path, num_elements):
    r"""
    Read ChannelNetwork 2D data files 
    
    :Input:
     - *path* (string) - Path to data file to be read in

    :Output:
     - (numpy.array(num_elements, 3)) Array containing 
       values of each field at the midpoints of elements 
    """

    # Open data file 
    data_file = open(path, 'r')

    # Create data arrays
    data_field = np.empty((num_elements, 3))

    # Read in data
    logging.info("Reading in the output data ...")
    data_file.readline()
    for i in xrange(num_elements):
			data_field[i,:] = map(float, data_file.readline().split())

    data_file.close()

    return data_field

def read_1D_crosssection_file(path):
	r"""
	Read in the nodes for the 1D cross-sections that we want to plot

	:Input
	- *path* (string) - Path to the file containing the node numbers

	:Output:
	- (numpy array containing the nodes)

	"""
	# create a list to hold the nodes that we are interested in
	cs_nodes = []

	# Read in the nodes file
	logging.info("Reading in the nodes of the cross-section we want to plot ...")
	with open(path, 'r') as nodes_file:
		for line in nodes_file:
			cs_nodes.append(int(line))

	cs_nodes_array = np.array(cs_nodes)
	num_cs_nodes = len(cs_nodes)
	return num_cs_nodes,cs_nodes_array

def read_SWASHES_Analytic_Sol(analyticSolPath):
	r"""
	Read in the analytical solution for certain 1D problem obtained from SWASHES.

	:Input
	- *analyticSolPath* (string) - path to the SWASHES file containing the anlytic solution

	:Output
	- numpy array (NumNodes X 8) containing coord, water height, velocity, bathymetry, 
	discharge, water surface height, Froude number and bathymetry+hc.

	"""

	# create a list to hold the values that we are interested in
	analyticSol = []
	
	numNodes = 0
	# Read in the solution from the file, skipping the comments
	for line in open(analyticSolPath):
		line = line.strip()
		if not line.startswith("#"):
			analyticSol.append(map(float,line.split()))
			numNodes += 1

	# create a numpy array
	analyticSolarr = np.empty((numNodes,8))
	for i in range(numNodes):
		analyticSolarr[i,:] = analyticSol[i]

	return analyticSolarr

def read_channels_output(PathToDir, fileNumber, chanNum):
	r"""
	Read the water surface elevation from all the channel files in a given directory.
	"""
	#for chanNum in xrange(numChannels):

		#for fileNumber in xrange(numFiles):
			# create a list to hold the values that we are interested in
	data_array = []
	numNodes = 0

	fileNumber = "{0:0=3d}".format(fileNumber)
	# Read in the solution from the file
	fileName = PathToDir +'/'+ fileNumber + '_ZetaChannel{}'.format(chanNum)+'.dat'
	openedFile = open(fileName, 'r')
	line = openedFile.readline()
	line = line.strip()
	m = re.search("# H and Zeta at time (\d+\.\d+) for Channel {}".format(chanNum),line) 
	time = float(m.group(1))		

	for line in openedFile:
		data_array.append(map(float, line.split()))

	openedFile.close()

	data_array = np.array(data_array)
	x_coords = data_array[:,0]
	y_coords = data_array[:,1]
	z_coords = data_array[:,2]
	height = data_array[:,3]
	zeta = data_array[:,4]

	num_data_points = len(x_coords)
	new_num_data_points = num_data_points/2
	x_coords = np.reshape(x_coords,(new_num_data_points ,2))
	dx = x_coords[:,1] - x_coords[:,0] 
	x_coords = np.mean(x_coords, axis=1)
	y_coords = np.reshape(y_coords, (num_data_points/2, 2))
	dy = y_coords[:,1] - y_coords[:,0]
	ds = np.sqrt(dx**2+dy**2)
	y_coords = np.mean(y_coords, axis=1)
	z_coords = np.reshape(z_coords, (num_data_points/2, 2))
	z_coords = np.mean(z_coords, axis=1)
	height = np.reshape(height, (num_data_points/2, 2))
	height = np.mean(height, axis=1)
	zeta = np.reshape(zeta, (num_data_points/2, 2))
	zeta = np.mean(zeta, axis=1)

	height = zeta + z_coords

	return time, x_coords, y_coords, z_coords, ds, zeta, height

