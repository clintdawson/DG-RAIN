import numpy as np
import my_io
import plotData
import matplotlib
import matplotlib.tri as tri
from matplotlib import rc_file
import matplotlib.pyplot as plt
from moviepy.video.io.bindings import mplfig_to_npimage
import moviepy.editor as mpy

def read_fort63(path):
	fort63_file = open(path, 'r')

	# Read header
	fort63_file.readline()
	
	# Read the second line
	[num_time_snaps, num_vals, dummy1, dummy2, dummy3] = fort63_file.readline().split()
	num_time_snaps = int(num_time_snaps)
	num_vals = int(num_vals)

	vals = np.empty((num_vals,num_time_snaps))
	time_array = np.empty((num_time_snaps,1))
	for snap in xrange(num_time_snaps):
		# Read current time and time step info
		[time, time_step_num] = fort63_file.readline().split()
		time = float(time)
		time_step_num = int(time_step_num)
		time_array[snap,0] = time

		for node in xrange(num_vals):
			[el_num, val] = fort63_file.readline().split()
			el_num = int(el_num)
			vals[node,snap]= float(val)
	
	return vals, time_array

def make_pngs(workingDir):
	gridFilePath = workingDir+"/fort.14"
	fort63Path = workingDir+"/fort.63"
	num_elements, num_nodes, coords, bathymetry, Triangles = my_io.read_grid_data(gridFilePath)

# calculate average bathymetry
	avgz = []
	for el in Triangles:
		v1 = el[0]
		v2 = el[1]
		v3 = el[2]
		avgz.append(0.33*(bathymetry[v1] + bathymetry[v2] + bathymetry[v3]))
	

	zeta_array, time_array = read_fort63(fort63Path)
	[num_vals, num_snaps] = zeta_array.shape
	num_vals = int(num_vals)
	num_snaps = int(num_snaps)

	height_array = np.empty(zeta_array.shape)

	for snap in xrange(num_snaps):
		height_array[:, snap] = zeta_array[:, snap] + avgz

	vmin = np.amin(height_array)
	vmax = np.amax(height_array)

	vmin_el = np.amin(zeta_array)
	vmax_el = np.amax(zeta_array)
	
	pngList=[]
	
	for snap in xrange(num_snaps):
		height = height_array[:,snap]
		figName = workingDir+"/Height{}.png".format(snap)
		plotData.plot2DNormal(coords, bathymetry, Triangles, data_field = height, plotName = figName, plt_title = 'Water Height at time {} s'.format(time_array[snap,0]),transparence_flag=False,vmin=0,vmax=5)
		#elevation = zeta_array[:, snap]
		#figName = workingDir+"/Elevation{}.png".format(snap)
		#plotData.plot2DNormal(coords, bathymetry, Triangles, data_field = elevation, plotName = figName, plt_title = 'Water surface elevation at time {} s'.format(time_array[snap,0]),transparence_flag=False,vmin=vmin_el,vmax=vmax_el)
		pngList.append(figName)

	#vals = data_array[:,num_snaps-1] 
	#vmin = np.amax(vals)
	#vmax = np.amax(vals)
	#figName =workingDir+"/DGSWEMHeight.png"
	#plotData.plot2DNormal(coords, bathymetry, Triangles, data_field = vals, plotName = figName, plt_title = 'Water Elevation at time {} s'.format(time_array[num_snaps-1,0]),transparence_flag=False,vmin=vmin, vmax=vmax)
	
	return pngList


def make_movie(workingDir):
	pngList = make_pngs(workingDir)
	clip = mpy.ImageSequenceClip(pngList, fps=8)
	#clip.write_videofile(workingDir+'/Animation.avi',codec='png')
	clip.write_videofile(workingDir+'/HeightAnimation.mp4')
	#clip.write_videofile(workingDir+'/ElevationAnimation.mp4')

make_movie('./DGSHEDFullWatershedFlooding')
#make_movie('./DGSHEDSimpleWatershed')
#make_movie('./FlatDomain_Fully2D')	
#make_movie('./FloodPlain/')	


