import numpy as np
from numpy import log10 as log
from my_io import read_grid_data
from my_io import read_data_file
from my_io import read_analytic_sol

def query_points(x_0, x_N, NumElx):
	x = np.linspace(x_0,x_N,num=NumElx);
	query_x = (x[0:len(x)-1]+x[1:len(x)])/2.
	return query_x

def extract_edg_num(TriangleXCoords, x_coord1, x_coord2):
	edg_num =np.empty([2,1])
	TriangleXCoords=np.array(TriangleXCoords)
	if (TriangleXCoords[0,0] == x_coord1 and TriangleXCoords[0,1] == x_coord2):
		edg_num[0] = 0
	elif (TriangleXCoords[0,1] == x_coord1 and TriangleXCoords[0,2] == x_coord2):
		edg_num[0] = 1
	else:
		edg_num[0] = 2
	
	if (TriangleXCoords[1,0] == x_coord1 and TriangleXCoords[1,1] == x_coord2):
		edg_num[1]=0
	elif (TriangleXCoords[1,1] == x_coord1 and TriangleXCoords[1,2] == x_coord2):
		edg_num[1]=1
	else:
		edg_num[1]=2

	return edg_num;


def find_triangles(Triangles, Coords, x_coord):
	UnsortedTriangleXCoords = np.array([Coords[Triangles[:,0],0], Coords[Triangles[:,1],0], Coords[Triangles[:,2],0]])
	UnsortedTriangleXCoords = np.transpose(UnsortedTriangleXCoords)
	TriangleXCoords = np.sort(UnsortedTriangleXCoords)
	TNum = TriangleXCoords[:,0].argsort()

	ContainingTriangle=[]

	leftx = 0
	rightx = 0

	for num in TNum:
		x1 = TriangleXCoords[num,0]
		x2 = TriangleXCoords[num,1]
		x3 = TriangleXCoords[num,2]

		if (x1 <= x_coord and x_coord <= x2):
			ContainingTriangle.append(num)
			leftx = x1
			rightx = x2
		elif (x2 <= x_coord and x_coord <= x3):
			ContainingTriangle.append(num)
			leftx = x2
			rightx = x3
		elif (x1 > x_coord):
			break
	
	if not ContainingTriangle:
		print "Containing Triangle not found"
	
	TriangleXCoords = [UnsortedTriangleXCoords[ContainingTriangle[0]], UnsortedTriangleXCoords[ContainingTriangle[1]]]
	edg_num = extract_edg_num(TriangleXCoords, leftx, rightx)
	
	return ContainingTriangle, edg_num

def calculate_edg_average(MidPointsVal, ContainingTriangle, edg_num):
	tri1 = ContainingTriangle[0]
	tri2 = ContainingTriangle[1]
	avgVal = 0.5*(MidPointsVal[tri1, edg_num[0][0]] + MidPointsVal[tri2, edg_num[1][0]])
	return avgVal

def calculate_average(NodalVal,ContainingTriangle,printVal=False):
	NumTri = len(ContainingTriangle)
	avgVal = []
	#avgVal = (NodalVal[ContainingTriangle[1],0] + NodalVal[ContainingTriangle[1],1] + NodalVal[ContainingTriangle[1],2])/3
	for tri in ContainingTriangle:
		avgVal.append((NodalVal[tri,0]+NodalVal[tri,1]+NodalVal[tri,2])/3.)
		if printVal:
			print "tri = ", tri
			print "avgVal = ", (NodalVal[tri,0]+NodalVal[tri,1]+NodalVal[tri,2])/3

	#avgVal = avgVal/NumTri
	if (NumTri != 2):
		print "numTri = ", NumTri
	return avgVal

def calculate_nodal_val(MidPointsVal):
	NodalVal = np.empty(MidPointsVal.shape)
	NodalVal[:,0] = MidPointsVal[:,0] - MidPointsVal[:,1] + MidPointsVal[:,2]
	NodalVal[:,1] = MidPointsVal[:,0] + MidPointsVal[:,1] - MidPointsVal[:,2]
	NodalVal[:,2] = -MidPointsVal[:,0] + MidPointsVal[:,1] + MidPointsVal[:,2]
	return NodalVal

x_0 = 0.
x_N = 25.
#NumElx = [50]
NumElx = [50, 100, 200, 500, 1000]
ErrorArray=[]

for num in NumElx:
	gridFilePath = "/h2/prapti/workrepo/ChannelNetwork/2DCode/SmoothSubcriticalFlow/ConvStudy/fort{fileNum}.14".format(fileNum=num)
	dataFilePath = "/h2/prapti/workrepo/ChannelNetwork/2DCode/SmoothSubcriticalFlow/ConvStudy/Zeta{fileNum}".format(fileNum=num)
	analyticFilePath = "/h2/prapti/workrepo/ChannelNetwork/2DCode/SmoothSubcriticalFlow/ConvStudy/AnalyticSol"

	NumEl, NumNodes, Coords, Z, T = read_grid_data(gridFilePath);
	ZetaMidVal = read_data_file(dataFilePath, NumEl)
	ZetaNodalVal = calculate_nodal_val(ZetaMidVal)

	AnalyticSol = read_analytic_sol(analyticFilePath)
	fineX = AnalyticSol[1:AnalyticSol.shape[0]-1,0]
	fineX = np.transpose(np.reshape(fineX, (len(fineX)/2,2)))
	fineSol = AnalyticSol[1:AnalyticSol.shape[0]-1,1]
	fineSol = np.transpose(np.reshape(fineSol, (len(fineSol)/2,2)))

	query_x = query_points(x_0, x_N, num+1)
	CoarseVal = []
	FineVal = []
	AbsDiffArray =[]

	xval = np.linspace(x_0,x_N,num+1)
	hx = (x_N - x_0)/num
	s = 0

	for x in query_x:
		ContainingTriangle, edg_num = find_triangles(T, Coords, x)
		avgVal = calculate_average(ZetaNodalVal, ContainingTriangle)
		edgAvg = calculate_edg_average(ZetaMidVal, ContainingTriangle, edg_num)

	
		while(x >= fineX[0,s]):
			s = s+1
		
		t = (x - fineX[0,s-1])/hx
		fineVal = (1-t)*fineSol[0,s-1] + t*fineSol[1,s-1]
		FineVal.append(fineVal)

		CoarseVal.append(edgAvg)
		#diff1 = abs(fineVal - avgVal[0])
		#diff2 = abs(fineVal - avgVal[1])
		#maxdiff = min(diff1, diff2)

		#AbsDiffArray.append(maxdiff)
		#print "fineVal = ", fineVal, "CoarseVal = ", edgAvg
		#AbsDiffArray.append(abs(fineVal - avgVal))
		AbsDiffArray.append(abs(fineVal - edgAvg))

	AbsDiffArray=np.array(AbsDiffArray)
	ind = np.argmax(AbsDiffArray)
	print "ind = ", ind
	Error = AbsDiffArray[ind]
	print "x = ", query_x[ind], "error = ", Error

	# find non-smooth regions
	z = -np.maximum(0,0.2-0.05*(xval-10)**2)
	badx = []
	j = 0;
	for k in range(len(z)-1):
		if ((z[k] == 0 and z[k+1] != 0) or (z[k] != 0 and z[k+1] == 0)):
			j = j + 1
			badx.append(xval[k])
			badx.append(xval[k+1])
	NumBadIntervals = j

	badx = np.array(badx)
	badx = np.reshape(badx, (len(badx)/2,2))

	print badx
	check_bad_interval = 1
	while(check_bad_interval==1):
		for j in range(NumBadIntervals):
			if (query_x[ind] >= badx[j,0] and query_x[ind] <= badx[j,1]):
				print "x = ",query_x[ind], "error = ", Error
				AbsDiffArray[ind] = 0
				ind = np.argmax(AbsDiffArray)
				Error = AbsDiffArray[ind]
				check_bad_interval = 1
				break;
			else:
				check_bad_interval = 0
	
	ErrorArray.append(Error)

print ErrorArray
logNumElx = log(NumElx)
logError = log(ErrorArray)
Slope = (logError[1:len(logError)] - logError[0:len(logError)-1])/(logNumElx[1:len(logError)] -logNumElx[0:len(logNumElx)-1])
print Slope
