import numpy as np
from matplotlib import cm
import matplotlib.tri as triClass
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from numpy.linalg import norm
from my_io import read_grid_data

def read_channel_nodes_file(Path):
	NodeList = []
	with open(Path, 'r') as CFile:
		# throw away first line
		CFile.readline()
		NumChannels = int(CFile.readline())
		for chan in xrange(NumChannels):
			NumNodes = int(CFile.readline())
			for node in xrange(NumNodes):
				Node = int(CFile.readline().split()[0])
				NodeList.append(Node-1)
	
	return NodeList

def read_flow_paths_file(Path, NumPoints):
	flow_x = []
	flow_y = []
	with open(Path, 'r') as Ffile:
		Ffile.readline()
		for i in xrange(NumPoints):
			[mid_x, mid_y] = [float(value) for value in Ffile.readline().split()]
			flow_x.append(mid_x)
			flow_y.append(mid_y)
	
	return [flow_x, flow_y]


#def read_flow_paths_file(Path, NumPoints):
#	bar_x = []
#	bar_y = []
#	u_arr = []
#	v_arr = []
#	with open(Path, 'r') as Ffile:
#		# throw away the first two lines
#		Ffile.readline()
#		Ffile.readline()
#		
#		for i in xrange(NumPoints):
#			line = Ffile.readline()
#			[x, y, u, v] = [float(value) for value in line.split()]
#			bar_x.append(x)
#			bar_y.append(y)
#			u_arr.append(u)
#			v_arr.append(v)
#
#		return[bar_x, bar_y, u_arr, v_arr]
	


def plot_watershed_grid(WatershedPath, ChannelsPath=None, figName=None):
	# read watershed grid
	[num_elements, num_nodes, coords, depth, triangles] = read_grid_data(WatershedPath)
	
	if (ChannelsPath):
		NodeList = read_channel_nodes_file(ChannelsPath)
		Cx = coords[NodeList, 0]
		Cy = coords[NodeList, 1]
		Cz = depth[NodeList]

	triangulation = triClass.Triangulation(coords[:,0], coords[:,1], triangles=triangles)

	# plot the Data
	fig1 = plt.figure()
	plt.gca().set_aspect('equal')
	ax1 = fig1.gca(projection='3d')
	surf = ax1.plot_trisurf(triangulation, -depth, cmap=cm.gist_earth, linewidth=0.2)
	if (ChannelsPath):
		ax1.plot(Cx, Cy, zs=-Cz, zdir='z', marker='o', color='r', ls='None')
	ax1.set_xlabel('x', fontsize=18)
	ax1.set_ylabel('y', fontsize=18)
	ax1.set_zlabel('Topography', fontsize=10)
	ax1.view_init(azim=-68, elev=71)
	fig1.colorbar(surf, shrink=0.5, aspect=10)
	if figName:
		plt.savefig(figName, bbox_inches='tight', transparent='True', pad_inches=0.1)
	else:
		plt.show()

def plot_flow_paths(WatershedPath, flowPathsFile, ChannelsPath=None, figName=None, transparence=False):
# read watershed grid
	[num_elements, num_nodes, coords, depth, triangles] = read_grid_data(WatershedPath)
	#[bar_x, bar_y, u, v] = read_flow_paths_file(flowPathsFile, num_elements)
	[flow_x, flow_y] = read_flow_paths_file(flowPathsFile, num_elements)
	x = coords[:,0]
	y = coords[:,1]
	bar_x = np.mean(x[triangles],axis=1)
	bar_y = np.mean(y[triangles],axis=1)
	u = []
	v = []
	for i in xrange(num_elements):
		edg_vec = np.array([flow_x[i] - bar_x[i], flow_y[i] - bar_y[i]])
		norm_edg_vec = norm(edg_vec)
		edg_vec = edg_vec/norm_edg_vec
		u.append(edg_vec[0])
		v.append(edg_vec[1])

	if (ChannelsPath):
		NodeList = read_channel_nodes_file(ChannelsPath)
		Cx = coords[NodeList, 0]
		Cy = coords[NodeList, 1]

	triangulation = triClass.Triangulation(coords[:,0], coords[:,1], triangles=triangles)

	fig2 = plt.figure()
	plt.gca().set_aspect('equal')
	plt.triplot(triangulation)
	if (ChannelsPath):
		plt.plot(Cx, Cy, marker='o', color='r', ls='None')
	
	plt.quiver(bar_x, bar_y, u, v, units='xy', color='blue', width=1.0, headwidth=3, headlength=4.0)
	plt.axis([-200,200,0,400])
	plt.xlabel('x', fontsize=18)
	plt.ylabel('y', fontsize=18)
	if figName:
		plt.savefig(figName, bbox_inches='tight', transparent=transparence, pad_inches=0.1)
	else:
		plt.show()

def main():
	#plot_watershed_grid('./TempInput/WatershedMesh.14', './TempInput/ChannelNodes.in', figName='./WatershedMeshWithChannels.png', transparence=True)
	plot_flow_paths('./DGSHEDFullWatershedFlooding/Floodplains.14', './DGSHEDFullWatershedFlooding/FlowPaths.out', './DGSHEDFullWatershedFlooding/ChannelNodes.in', figName='./DGSHEDFullWatershedFlooding/KinematicFlowPaths.png')

if __name__ == "__main__":
	main()

