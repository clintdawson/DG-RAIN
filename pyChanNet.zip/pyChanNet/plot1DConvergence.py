import my_io
import os
import numpy as np
from math import log10 as log
import matplotlib
#matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import rc_file

#NumMidPoints=[40]
NumMidPoints=[40,80,160,320,640,1280,2560]
sizeArray = len(NumMidPoints)
HError=np.empty([sizeArray,2])
ZetaError=np.empty([sizeArray,2])
QError = np.empty([sizeArray,2])
HlogError=np.empty([sizeArray,2])
ZetalogError=np.empty([sizeArray,2])
QlogError = np.empty([sizeArray,2])
HSlope = np.empty([sizeArray-1,1])
ZetaSlope = np.empty([sizeArray-1,1])
ZetaMidError = np.empty([sizeArray,2])
ZetalogMidError = np.empty([sizeArray,2])
ZetaMidSlope = np.empty([sizeArray-1,1])
QMidError = np.empty([sizeArray,2])
QlogMidError = np.empty([sizeArray,2])
QMidSlope = np.empty([sizeArray-1,1])


AnalyticFileNum=5120

i=0
for num in NumMidPoints:
	fileNumber=num

	ZetaFilePath = "/org/groups/chg/prapti/results/1DConvStudy/subcritical/RoeFlux/Zeta{fileNum}".format(fileNum=fileNumber)
	QFilePath = "/org/groups/chg/prapti/results/1DConvStudy/subcritical/RoeFlux/Q{fileNum}".format(fileNum=fileNumber)
	analyticZetaPath = "/org/groups/chg/prapti/results/1DConvStudy/subcritical/Zeta{}".format(AnalyticFileNum)
	analyticQPath = "/org/groups/chg/prapti/results/1DConvStudy/subcritical/Q{}".format(AnalyticFileNum)

	
	x_analytic, AnalyticH1, AnalyticH2,zanal = my_io.return_plotCoord_and_data(analyticZetaPath, AnalyticFileNum+1, False)
	x_analytic, AnalyticZeta1, AnalyticZeta2,zanal = my_io.return_plotCoord_and_data(analyticZetaPath, AnalyticFileNum+1, True)
	x_analytic, AnalyticQ1, AnalyticQ2,zanal = my_io.return_plotCoord_and_data(analyticQPath, AnalyticFileNum+1, False)
	x_numeric, HNumerical1, HNumerical2,z = my_io.return_plotCoord_and_data(ZetaFilePath, num+1, False)
	x_numeric, ZetaNumerical1, ZetaNumerical2,z = my_io.return_plotCoord_and_data(ZetaFilePath, num+1, True)
	
	plotCoord, QNumerical1, QNumerical2,z = my_io.return_plotCoord_and_data(QFilePath, num+1, False)

	x_analytic = np.array(x_analytic)
	AnalyticH1 = np.array(AnalyticH1)
	AnalyticH2 = np.array(AnalyticH2)
	x_numeric = np.array(x_numeric)	
	HNumerical1 = np.array(HNumerical1)
	HNumerical2 = np.array(HNumerical2)
	ZetaAnalytic1 = np.array(AnalyticZeta1)
	ZetaAnalytic2 = np.array(AnalyticZeta2)
	ZetaNumerical1 = np.array(ZetaNumerical1)
	ZetaNumerical2 = np.array(ZetaNumerical2)
	z = np.array(z)

	factor = AnalyticFileNum/num

	AnalyticZetaMid = np.empty((num,1))
	AnalyticQMid =np.empty((num,1))

	k = 1;
	while k<=num:
		x_mid = (x_numeric[k]+x_numeric[k-1])*0.5;
		ind = k*factor-factor/2
		x_anal = x_analytic[ind]
		if (x_mid != x_anal):
			print k 
		else:
			AnalyticZetaMid[k-1]=AnalyticZeta2[ind]
			AnalyticQMid[k-1]=0.5*(AnalyticQ1[ind]+AnalyticQ2[ind])
		k=k+1
	
	NumericalZetaMid = np.empty((num,1))
	NumericalQMid = np.empty((num,1))
	
	for el in range(0,num):
		NumericalZetaMid[el] = (ZetaNumerical2[el]+ZetaNumerical1[el+1])*0.5
		NumericalQMid[el] = (QNumerical2[el]+QNumerical1[el+1])*0.5

	diffZetaMid = NumericalZetaMid - AnalyticZetaMid
	absdiffZetaMid = np.absolute(diffZetaMid)	
	ZetaMidlinfError = np.amax(absdiffZetaMid)
	diffind = np.nonzero(absdiffZetaMid == ZetaMidlinfError)[0][0]
	while ((z[diffind]== 0 and z[diffind+1] != 0) or (z[diffind] != 0 and z[diffind+1] ==0)):
		absdiffZetaMid[diffind] = absdiffZetaMid[diffind-1]
		ZetaMidlinfError = np.amax(absdiffZetaMid)
		diffind = np.nonzero(absdiffZetaMid == ZetaMidlinfError)[0][0]
	
#	print ZetaMidlinfError
	
	ZetaMidError[i,0] = num
	ZetaMidError[i,1] = ZetaMidlinfError
	ZetalogMidError[i,0] = log(NumMidPoints[i])
	ZetalogMidError[i,1] = log(ZetaMidlinfError)

	diffQMid = NumericalQMid - AnalyticQMid
	absdiffQMid = np.absolute(diffQMid)	
	QMidlinfError = np.amax(absdiffQMid)
#	print QMidlinfError

	QMidError[i,0] = num
	QMidError[i,1] = QMidlinfError
	QlogMidError[i,0] = log(num)
	QlogMidError[i,1] = log(QMidlinfError)


	if i > 0:
		ZetaMidSlope[i-1] = (ZetalogMidError[i,1] - ZetalogMidError[i-1,1])/(ZetalogMidError[i,0] - ZetalogMidError[i-1,0])	
		QMidSlope[i-1] = (QlogMidError[i,1] - QlogMidError[i-1,1])/(QlogMidError[i,0] - QlogMidError[i-1,0])	

	i=i+1

print ZetaMidSlope
print "**********************"
print QMidSlope

print (ZetalogMidError[sizeArray-1,1] - ZetalogMidError[0,1])/(ZetalogMidError[sizeArray-1,0] - ZetalogMidError[0,0])

currdir = os.getcwd()
rc_file(currdir+'/my_matplotlib.rc')
fig = plt.figure()
lines=plt.loglog(ZetaMidError[:,0], ZetaMidError[:,1], ZetaMidError[:,0], 3*(ZetaMidError[:,0])**(-2))
plt.setp(lines[0], color='red', linewidth=1.5, marker='o', linestyle='--')
plt.setp(lines[1], color='blue', linewidth=1.5)
plt.xlabel('N')
plt.ylabel(r"$L^{\infty}$ Error")
plt.legend(lines,['Water Surface', 'Line with slope -2'])
##plt.savefig("ZetaErrorLF.png")
##plt.savefig("HErrorRoeFlux.png")
##plt.savefig("ZetaErrorRoeFlux.png")
##plt.savefig("ZetaErrorLFMinmod.png")
##plt.savefig("ZetaErrorRoeFluxMinmod.png")
#plt.show()

plt.tight_layout(pad=0.1)
plt.savefig("ZetaErrorRoeFlux.png", bbox_inches='tight', transparent=True, pad_inches=0)
plt.savefig("ZetaErrorRoeFlux.pdf", bbox_inches='tight', transparent=True, pad_inches=0)
