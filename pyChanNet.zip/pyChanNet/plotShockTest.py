import os
import numpy as np
import matplotlib.pyplot as plt
from matplotlib import rc_file

OneDFilePath = "/org/groups/chg/prapti/results/ShockTest/ShockTest1DZeta.dat"
JunctionModelFilePath="/org/groups/chg/prapti/results/ShockTest/ShockTestJunctionModelMergedZeta.dat"

OneDSol = np.loadtxt(OneDFilePath)
JunctionModelSol = np.loadtxt(JunctionModelFilePath)

x_coord = OneDSol[:,0]
OneDVal = OneDSol[:,3]
JunctionVal = JunctionModelSol[:,1]
Junctionx = JunctionModelSol[:,0]


currdir = os.getcwd()
rc_file(currdir+'/my_matplotlib.rc')
fig = plt.figure()
lines = plt.plot(x_coord, OneDVal, '+', Junctionx, JunctionVal, '.')
plt.setp(lines[0], color='blue', linewidth = 2.0)
plt.setp(lines[1], color='magenta', linewidth=2.0)
plt.legend(lines, [r"1D Solution", r"Heterogenous Junction Model Solution"])  
plt.ylabel("Water Surface Height")
plt.xlabel("x")
plt.axis([0,1000,0,12])
#plt.show()
plt.tight_layout(pad=0.1)
fileName='/workspace/prapti/Dropbox/ChannelNetworksPaper/Pictures/ShockTest.pdf'
#fileName='/workspace/prapti/Dropbox/ChannelNetworksPaper/Pictures/{}2D.pdf'.format(case)
plt.savefig(fileName, bbox_inches='tight', transparent=True, pad_inches=0)
plt.close()

