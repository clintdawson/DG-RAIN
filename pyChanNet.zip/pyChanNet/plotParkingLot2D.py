import my_io
import processDataField
import plotData




# 2D plotting

# T MESH

gridFilePath = "/org/groups/chg/prapti/repos/KinField/ParkingLot/Version8/ParkingLotMesh.14"
#dataFilePath = "/h2/prapti/workrepo/ChannelNetwork/2DCode/Tmesh/CoarseGrid/001_H.dat"

num_elements, num_nodes, coords, bathymetry, Triangles = my_io.read_grid_data(gridFilePath)

figName = "/org/groups/chg/prapti/results/ParkingLot1/ParkingLotMesh.pdf"
#plotData.plot2DNormal(coords, -bathymetry, Triangles)
plotData.plot2DNormal(coords, -bathymetry, Triangles, meshName=figName)

