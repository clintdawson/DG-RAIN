import my_io
import processDataField
import plotData



#gridFilePath = "/h2/prapti/workrepo/ChannelNetwork/src/JunctionMeshedSeparately/TChannel/LargerJunctionSize/CoarseJunctionMesh/CoarseJunctionMesh.in"
#dataFilePath = "/h2/prapti/workrepo/ChannelNetwork/src/DifferentMeshing/test/126_Zeta_junc0.dat"

#dataFilePath = "/h2/prapti/workrepo/ChannelNetwork/2DCode/DamBreakDryBed/data/122_H.dat"
#gridFilePath = "/h2/prapti/workrepo/ChannelNetwork/2DCode/DamBreakDryBed/DamBreakFort1000.14"
#csNodesFilePath = "/h2/prapti/workrepo/ChannelNetwork/2DCode/DamBreakDryBed/NodesOnXAxis.in"
#analyticSolPath = "/h2/prapti/workrepo/ChannelNetwork/1DCode/Tests/AnalyticalDamBreakDryBed.dat"
#
#figName = "/workspace/prapti/Dropbox/ChannelNetworksPaper/Pictures/DamBreakDryBed2D.pdf"
#
#num_elements, num_nodes, coords, bathymetry, Triangles = my_io.read_grid_data(gridFilePath)
#
#Hnodal = processDataField.calculate_avg_nodal_val(dataFilePath, num_elements, num_nodes, Triangles)
#cs_coord, cs_bathymetry, cs_H = processDataField.extract_crosssection_data(csNodesFilePath, coords, bathymetry, Hnodal)
#
#cs_Zeta = processDataField.calculate_zeta_from_height(cs_H, cs_bathymetry)
#
#analytic_x_coord, H, bathymetry, discharge, waterSurfHeight = processDataField.extract_SWASHES_analytic_values(analyticSolPath)
#
#plotData.plot1D(cs_coord[:,0], cs_Zeta , coord1=analytic_x_coord, data_field1=waterSurfHeight, data_field2=-cs_bathymetry, coord2= None, ylabel=r"Water Surface Height", plotName=figName)
#plotData.plot1D(cs_coord[:,0], cs_Zeta , data_field2=-cs_bathymetry, coord2= None,plotName=figName,ylabel=r"Water Surface Height")
#plotData.plot1D(cs_coord[:,0], cs_Zeta , bathymetry=-cs_bathymetry, xcoordAnalyticSol= None, analyticSol=None,plotName=figName)
#plotData.plot1D(cs_coord[:,0], cs_H, bathymetry=-cs_bathymetry, xcoordAnalyticSol=analytic_x_coord, analyticSol=H,plotName=figName)
#plotData.plot1D(cs_coord[:,0], cs_H, bathymetry=-cs_bathymetry, xcoordAnalyticSol=analytic_x_coord, analyticSol=H,plotName=None)



# 2D plotting

# T MESH

#gridFilePath = "/h2/prapti/workrepo/ChannelNetwork/2DCode/Tmesh/CoarseGrid/CoarseTMesh.14"
#dataFilePath = "/h2/prapti/workrepo/ChannelNetwork/2DCode/Tmesh/CoarseGrid/001_H.dat"
#QxFilePath = "/h2/prapti/workrepo/ChannelNetwork/2DCode/Tmesh/CoarseGrid/001_Qx.dat"
#VelFigname = "/workspace/prapti/Dropbox/ChannelNetworksPaper/Pictures/TMeshCoarseFully2DVelocity.pdf"
#gridFilePath = "/h2/prapti/workrepo/ChannelNetwork/2DCode/Tmesh/Tmesh.14"
#dataFilePath = "/h2/prapti/workrepo/ChannelNetwork/2DCode/Tmesh/450_H.dat"
#QxFilePath = "/h2/prapti/workrepo/ChannelNetwork/2DCode/Tmesh/450_Qx.dat"
#ZetaFigname = "/h2/prapti/workrepo/ChannelNetwork/ModelDoc/Pictures/TMeshFully2DZeta.pdf"
#VelFigname = "/h2/prapti/workrepo/ChannelNetwork/ModelDoc/Pictures/TMeshFully2DVelocity.pdf"
#meshFigName = "/h2/prapti/workrepo/ChannelNetwork/ModelDoc/Pictures/TMeshFully2D.pdf"
#meshFigName = "/workspace/prapti/Dropbox/ChannelNetworksPaper/Pictures/TMeshFully2D.pdf"

#gridFilePath = "/h2/prapti/workrepo/ChannelNetwork/src/JunctionMeshedSeparately/TChannel/LargerJunctionSize/CoarseJunctionMesh/CoarseJunctionMesh.in"
#dataFilePath = "/h2/prapti/workrepo/ChannelNetwork/src/JunctionMeshedSeparately/TChannel/LargerJunctionSize/CoarseJunctionMesh/001_Height_junc0.dat"
#QxFilePath = "/h2/prapti/workrepo/ChannelNetwork/src/JunctionMeshedSeparately/TChannel/LargerJunctionSize/CoarseJunctionMesh/001_Qx_junc0.dat"
#VelFigname = "/workspace/prapti/Dropbox/ChannelNetworksPaper/Pictures/TMeshCoarseLargerJunctionVelocity.pdf"
#gridFilePath = "/h2/prapti/workrepo/ChannelNetwork/src/JunctionMeshedSeparately/TChannel/LargerJunctionSize/CoarseJunctionMesh/CoarseJunctionMesh.in"
#gridFilePath = "/h2/prapti/workrepo/ChannelNetwork/src/JunctionMeshedSeparately/TChannel/LargerJunctionSize/JunctionMesh.in"
#dataFilePath = "/h2/prapti/workrepo/ChannelNetwork/src/JunctionMeshedSeparately/TChannel/LargerJunctionSize/040_Height_junc0.dat"
#QxFilePath = "/h2/prapti/workrepo/ChannelNetwork/src/JunctionMeshedSeparately/TChannel/LargerJunctionSize/040_Qx_junc0.dat"
#ZetaFigname = "/h2/prapti/workrepo/ChannelNetwork/ModelDoc/Pictures/TMeshLargerJunctionZeta.pdf"
#VelFigname = "/h2/prapti/workrepo/ChannelNetwork/ModelDoc/Pictures/TMeshLargerJunctionVelocity.pdf"
#meshFigName = "/h2/prapti/workrepo/ChannelNetwork/ModelDoc/Pictures/TMeshLargerJunction.pdf"
#meshFigName = "/workspace/prapti/Dropbox/ChannelNetworksPaper/Pictures/TMeshLargerJunction.pdf"

#gridFilePath = "/h2/prapti/workrepo/ChannelNetwork/src/JunctionMeshedSeparately/TChannel/SmallerJunctionSize/CoarseMesh/CoarseJunctionMesh.in"
#dataFilePath = "/h2/prapti/workrepo/ChannelNetwork/src/JunctionMeshedSeparately/TChannel/SmallerJunctionSize/CoarseMesh/348_Height_junc0.dat"
#QxFilePath = "/h2/prapti/workrepo/ChannelNetwork/src/JunctionMeshedSeparately/TChannel/SmallerJunctionSize/CoarseMesh/348_Qx_junc0.dat"
#VelFigname = "/workspace/prapti/Dropbox/ChannelNetworksPaper/Pictures/TMeshCoarseSmallerJunctionVelocity.pdf"
#gridFilePath = "/h2/prapti/workrepo/ChannelNetwork/src/JunctionMeshedSeparately/TChannel/SmallerJunctionSize/JunctionMesh.in"
#dataFilePath = "/h2/prapti/workrepo/ChannelNetwork/src/JunctionMeshedSeparately/TChannel/SmallerJunctionSize/029_Height_junc0.dat"
#QxFilePath = "/h2/prapti/workrepo/ChannelNetwork/src/JunctionMeshedSeparately/TChannel/SmallerJunctionSize/029_Qx_junc0.dat"
#ZetaFigname = "/h2/prapti/workrepo/ChannelNetwork/ModelDoc/Pictures/TMeshSmallerJunctionZeta.pdf"
#VelFigname = "/h2/prapti/workrepo/ChannelNetwork/ModelDoc/Pictures/TMeshSmallerJunctionVelocity.pdf"
#meshFigName = "/h2/prapti/workrepo/ChannelNetwork/ModelDoc/Pictures/TMeshSmallerJunction.pdf"
#meshFigName = "/workspace/prapti/Dropbox/ChannelNetworksPaper/Pictures/TMeshSmallerJunction.pdf"

# Angled T Mesh

#gridFilePath = "/h2/prapti/workrepo/ChannelNetwork/2DCode/AngledTMesh/CoarseFort.14"
#dataFilePath = "/h2/prapti/workrepo/ChannelNetwork/2DCode/AngledTMesh/318_H.dat"
#QxFilePath = "/h2/prapti/workrepo/ChannelNetwork/2DCode/AngledTMesh/080_Qx.dat"
##ZetaFigname = "/h2/prapti/workrepo/ChannelNetwork/ModelDoc/Pictures/AngledChannelFully2DHeight.pdf"
#ZetaFigname = "/h2/prapti/workrepo/ChannelNetwork/ModelDoc/Pictures/AngledChannelFully2DZoomedHeight.pdf"
#VelFigname = "/h2/prapti/workrepo/ChannelNetwork/ModelDoc/Pictures/AngledChannelFully2DVelocity.pdf"
#meshFigName = "/h2/prapti/workrepo/ChannelNetwork/ModelDoc/Pictures/AngledChannelFully2D.pdf"

#gridFilePath = "/h2/prapti/workrepo/ChannelNetwork/src/JunctionMeshedSeparately/AngledChannel/JunctionMesh.in"
#dataFilePath = "/h2/prapti/workrepo/ChannelNetwork/src/JunctionMeshedSeparately/AngledChannel/029_Height_junc0.dat"
#QxFilePath = "/h2/prapti/workrepo/ChannelNetwork/src/JunctionMeshedSeparately/AngledChannel/029_Qx_junc0.dat"
#ZetaFigname = "/h2/prapti/workrepo/ChannelNetwork/ModelDoc/Pictures/AngledChannelJunctionHeight.pdf"
#VelFigname = "/h2/prapti/workrepo/ChannelNetwork/ModelDoc/Pictures/AngledChannelJunctionVelocity.pdf"
#meshFigName = "/h2/prapti/workrepo/ChannelNetwork/ModelDoc/Pictures/AngledChannelJunction.pdf"

#gridFilePath = "/h2/prapti/workrepo/ChannelNetwork/src/JunctionMeshedSeparately/ConservationExample/JunctionMesh.in"
#dataFilePath = "/h2/prapti/workrepo/ChannelNetwork/src/JunctionMeshedSeparately/ConservationExample/049_Height_junc0.dat"
#QxFilePath = "/h2/prapti/workrepo/ChannelNetwork/src/JunctionMeshedSeparately/ConservationExample/049_Qx_junc0.dat"
#ZetaFigname = "/h2/prapti/workrepo/ChannelNetwork/ModelDoc/Pictures/ConservationExampleJunctionHeight.pdf"
#VelFigname = "/h2/prapti/workrepo/ChannelNetwork/ModelDoc/Pictures/ConservationExampleJunctionVelocity.pdf"
#meshFigName = "/h2/prapti/workrepo/ChannelNetwork/ModelDoc/Pictures/ConservationExampleJunction.pdf"

# Floodplain
gridFilePath = "FloodPlain/fort.14"

num_elements, num_nodes, coords, bathymetry, Triangles = my_io.read_grid_data(gridFilePath)
#HNodal = processDataField.calculate_avg_nodal_val(dataFilePath, num_elements, num_nodes, Triangles)
#QNodal = processDataField.calculate_avg_nodal_val(QxFilePath, num_elements, num_nodes,Triangles)
#uNodal = QNodal/HNodal


#ZetaNodal = ZetaNodal/0.914
#uNodal = uNodal/0.628

#plotData.plot2D(coords, -bathymetry, Triangles)
#plotData.plot2DNormal(coords, -bathymetry, Triangles,meshName='./FloodPlain/FloodPlainMesh.pdf')
plotData.plot2DNormal(coords, -bathymetry, Triangles)

#plotData.plot2D(coords, -bathymetry, Triangles, data_field=uNodal, data_field_format='contour', plotName=VelFigname)
#plotData.plot2D(coords, -bathymetry, Triangles, data_field=uNodal, data_field_format='contour')
#plotData.plot2D(coords, -bathymetry, Triangles, data_field=HNodal)
#plotData.plot2D(coords, -bathymetry, Triangles, data_field=HNodal, data_field_format='contour')
#plotData.plot2D(coords, -bathymetry, Triangles, data_field=HNodal, data_field_format='contour', plotName=ZetaFigname)
#plotData.plot2D(coords, -bathymetry, Triangles)
#plotData.plot2D(coords, -bathymetry, Triangles, meshName = meshFigName)

#Channel0DataFilePath = "/h2/prapti/workrepo/ChannelNetwork/src/JunctionMeshedSeparately/AngledChannel/029_Zeta0.dat"
#Channel1DataFilePath = "/h2/prapti/workrepo/ChannelNetwork/src/JunctionMeshedSeparately/AngledChannel/029_Zeta1.dat"
#Channel2DataFilePath = "/h2/prapti/workrepo/ChannelNetwork/src/JunctionMeshedSeparately/AngledChannel/029_Zeta2.dat"
#figName = "/h2/prapti/workrepo/ChannelNetwork/ModelDoc/Pictures/AngledChannelsCombinedHeight.pdf"
#coord0, HNodal0 = processDataField.calculate_avg_nodal_val_1D(Channel0DataFilePath, 31)
#coord1, HNodal1 = processDataField.calculate_avg_nodal_val_1D(Channel1DataFilePath, 31)
#coord2, HNodal2 = processDataField.calculate_avg_nodal_val_1D(Channel2DataFilePath, 31)
##plotData.plot1D(coord, HNodal)
##plotData.plot1D(coord, HNodal,plotName=figName)
#plotData.plot1D(coord0, HNodal0, coord1, HNodal1, coord2, HNodal2, plotName=figName, figTitle0='Channel 0', figTitle1 = 'Channel 1', figTitle2 = 'Channel 2', xlabel = 'Distance from the upstream end of the channel', ylabel = 'Water Height')
#plotData.plot1DSubPlots(coord0, HNodal0, coord1, HNodal1, coord2, HNodal2)
