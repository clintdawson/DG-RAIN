from mpl_toolkits.mplot3d import Axes3D
from mpl_toolkits.mplot3d.art3d import Poly3DCollection
from matplotlib.colors import colorConverter
import matplotlib.pyplot as plt
from matplotlib import rc_file
import os

currdir = os.getcwd()
rc_file(currdir+'/my_matplotlib.rc')

fig = plt.figure()
ax = Axes3D(fig)
cc = lambda arg: colorConverter.to_rgba(arg, alpha=0.6)

verts = [[(-600,100,101.3),(-600,0,96.3), (0,0,-0.1), (600,0,96.3),(600,100,101.3),(0,100,4.9)]]

poly = Poly3DCollection(verts, facecolors = [cc('g')])

ax.add_collection3d(poly)
#ax.add_collection3d(Poly3DCollection(verts))


bayverts=[[(-600,0,-0.1), (-600,-100,-0.1), (600,-100,-0,1), (600, 0,-0.1)]]
baypoly = Poly3DCollection(bayverts,facecolors=[cc('b')])
ax.add_collection3d(baypoly)

walverts1 = [[(-600,0,96.3),(-600,0,-0.1),(0,0,-0.1)]]
walverts2 = [[(600,0,96.3),(600,0,-0.1),(0,0,-0.1)]]

walpoly1 = Poly3DCollection(walverts1, facecolor='k', alpha=1.0)
walpoly2 = Poly3DCollection(walverts2, facecolor='k', alpha=1.0)

ax.add_collection3d(walpoly1)
ax.add_collection3d(walpoly2)

ax.add_collection3d(Poly3DCollection([[(0,0,-0.1),(0,100,4.9)]], edgecolors='r', lw=2))

#ax.set_xlabel('X')
ax.set_xlim3d(-601, 601)
#ax.set_ylabel('Y')
ax.set_ylim3d(-101, 101)
#ax.set_zlabel('Z')
ax.set_zlim3d(-0.02, 101)
ax.view_init(elev=40, azim=-101)

#plt.show()
#plt.tight_layout(pad=0.1)
plt.savefig('/org/groups/chg/prapti/results/TwoParkingLotsAndBay.pdf',bbox_inches='tight', transparent=True, pad_inches=0)
