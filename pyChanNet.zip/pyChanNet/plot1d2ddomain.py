import os
import sys
import numpy as np
from math import sqrt, atan, atan2, sin, cos, pi, floor
import re
import matplotlib
import matplotlib.tri as tri
from matplotlib import rc_file
import matplotlib.pyplot as plt
from moviepy.video.io.bindings import mplfig_to_npimage
import moviepy.editor as mpy
import matplotlib.patches as mpatches
from matplotlib.path import Path
from matplotlib.collections import PolyCollection
from matplotlib.collections import PatchCollection
import my_io

# make a rectangular box around the line connecting (x1,y1)
# and (x2,y2) by finding points that lie on the line 
# perpendicular to this line
def make_rect_nodes(x1,x2,y1,y2,b1,b2):
	b1 = b1
	b2 = b2
	rect_box = []

	norm_vec = [-(y2-y1), x2-x1]
	vec_len = sqrt((y2-y1)*(y2-y1) + (x2-x1)*(x2-x1))
	norm_vec[0] = norm_vec[0]/vec_len
	norm_vec[1] = norm_vec[1]/vec_len

	rect_box.append((x1+0.5*b1*norm_vec[0] , y1+0.5*b1*norm_vec[1]))
	rect_box.append((x1-0.5*b1*norm_vec[0] , y1-0.5*b1*norm_vec[1]))
	rect_box.append((x2+0.5*b2*norm_vec[0] , y2+0.5*b2*norm_vec[1]))
	rect_box.append((x2-0.5*b2*norm_vec[0] , y2-0.5*b2*norm_vec[1]))

	return rect_box

def sort_counterclockwise_order(rect_box):
	xcenter = 0.25*(rect_box[0][0] + rect_box[1][0] + rect_box[2][0] + rect_box[3][0])
	ycenter = 0.25*(rect_box[0][1] + rect_box[1][1] + rect_box[2][1] + rect_box[3][1])
	angleList = []
	vertDict = {}
	for vertex in rect_box:
		x = vertex[0]
		y = vertex[1]
		angle = atan2(y-ycenter,x-xcenter)
		angleList.append(angle)
		vertDict[angle] = vertex

	angleList = sorted(angleList)
	sortedVertices = []
	for key in angleList:
		sortedVertices.append(vertDict[key])

	sortedVertices.append(sortedVertices[0])
	return sortedVertices

def read_channels_grid_file(path):
	channels_file = open(path, 'r')
	
	# Read number of channels
	line = channels_file.readline()
	NumChannels = int(line)
	RectangularBoxes = []
	for ch in xrange(NumChannels):
	# read numnodes
		NumNodes = int(channels_file.readline())
		ch_x = []
		ch_y = []
		ch_b = []
		for n in xrange(NumNodes):
			[x, y, z, b, m1, m2, n] = [float(value) for value in channels_file.readline().split()]
			ch_x.append(x)
			ch_y.append(y)
			ch_b.append(b)
		for el in xrange(NumNodes-1):
			x1 = ch_x[el]
			y1 = ch_y[el]
			x2 = ch_x[el+1]
			y2 = ch_y[el+1]
			rect_box = make_rect_nodes(ch_x[el], ch_x[el+1], ch_y[el], ch_y[el+1], ch_b[el],ch_b[el+1])
			rect_box = sort_counterclockwise_order(rect_box)

			RectangularBoxes.append(rect_box)

	return RectangularBoxes

def read_junctions_grid_file(path):
	junctions_file = open(path, 'r')

	# Read number of junctions
	NumJunctions = int(junctions_file.readline())
	triangulationArray = []
	for i in xrange(NumJunctions):
		[NumEls, NumNodes] = [int(value) for value in junctions_file.readline().split()]
		x = []
		y = []
		trianglesArray = np.empty((NumEls,3), dtype='int32')

		# Read in coordinates of each node
		for n in xrange(NumNodes):
			line = junctions_file.readline().split()
			x.append(float(line[1]))
			y.append(float(line[2]))
			x[n] = x[n]
			y[n] = y[n]

		# Read in triangles
		for t in xrange(NumEls):
			line = junctions_file.readline().split()
			trianglesArray[t,0] = int(line[2])-1
			trianglesArray[t,1] = int(line[3])-1
			trianglesArray[t,2] = int(line[4])-1

		triangulation = tri.Triangulation(x,y,triangles=trianglesArray)
		triangulationArray.append(triangulation)

	return triangulationArray

ChannelsGridFilePath = 'ChannelNodes.in'
JunctionsGridFilePath = 'fort.14'

# read in the grid files
rectangularBoxes = read_channels_grid_file(ChannelsGridFilePath)
triangulationArray = read_junctions_grid_file(JunctionsGridFilePath)

# plot
rc_file('my_matplotlib.rc')
fig = plt.figure()
ax = plt.subplot(1,1,1)
ax.set_xlim(-600,600)
ax.set_ylim(-1200,600)
ax.set_aspect('equal')
ax.locator_params(axis='x', nbins=4)
plt.triplot(triangulationArray[0], color='g')

# plot chanels data
codes = [Path.MOVETO, Path.LINETO, Path.LINETO, Path.LINETO, Path.CLOSEPOLY,]
patches = []
facecolors = []
for verts in rectangularBoxes:
	path = Path(verts, codes)
	patch = mpatches.PathPatch(path, lw=2)
	patches.append(patch)
	facecolors.append(1)

Channels = PatchCollection(patches, facecolors='w', edgecolors='g', alpha=1)
#Channels.set_array(np.array(facecolors))
#Channels.set_clim([vmin, vmax])
ax.add_collection(Channels)	

plt.xlabel('x (m)', fontsize=18)
plt.ylabel('y (m)', fontsize=18)
#plt.show()
plt.savefig('Coupled1D2DBayChannelMesh.pdf', transparent=True, bbox_inches='tight', pad_inches=0)
