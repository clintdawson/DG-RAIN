r""" Functions to calculate the average value at each node across elements """

import logging

import numpy as np

import my_io
#from matplotlib.tri import LinearTriInterpolator as triInterp

def calculate_avg_nodal_val_1D(dataFilePath,num_nodes):
	plot_coord, data_field = my_io.return_plotCoord_and_data(dataFilePath, num_nodes)
	return plot_coord, data_field

def calculate_avg_nodal_val(dataFilePath, num_elements, num_nodes,T, data_field=None):
	if (data_field == None):
		data_field = my_io.read_data_file(dataFilePath, num_elements)

	nodal_data_field = np.empty((num_elements,3))
	for j in range(3):
		n0 = j;
		n1 = (j+1)%3
		n2 = (j+2)%3
		nodal_data_field[:,j] = data_field[:,n0]- data_field[:,n1] + data_field[:,n2]

	avg_nodal_data_field = np.zeros((num_nodes))

	# Calculate the average values at all the nodes
	for i in range(num_nodes):
		nodeNum = i
		positions = np.where(T==nodeNum)
		elNums = positions[0]
		local_node_nums = positions[1]
		curr_nodal_data_field = np.array(nodal_data_field[elNums, local_node_nums])
		avg_nodal_data_field[i] = np.mean(curr_nodal_data_field)

	return avg_nodal_data_field

def calculate_zeta_from_height(height, bathymetry):
	zeta = height - bathymetry
	return zeta


def extract_crosssection_data(csNodesFilePath, coords, depth, avg_nodal_data_field):
	num_cs_nodes, cs_nodes = my_io.read_1D_crosssection_file(csNodesFilePath)
	
	# Extract the coordinates at the cross-sectional nodes
	cs_coord = coords[cs_nodes,:]

	# Extract the values of the data field, the bathymetry and the analytical solution 
	# at the cross-sectional nodes
	data_field_of_interest = avg_nodal_data_field[cs_nodes]
	bathymetry = depth[cs_nodes]

	return cs_coord, bathymetry, data_field_of_interest

def extract_SWASHES_analytic_values(analyticSolPath):
	analyticSol = my_io.read_SWASHES_Analytic_Sol(analyticSolPath)
	x_coord = []
	H = []
	bathymetry = []
	discharge = []
	waterSurfHeight =[]
	for list in analyticSol:
		x_coord.append(list[0])
		H.append(list[1])
		bathymetry.append(list[3])
		discharge.append(list[4])
		waterSurfHeight.append(list[5])


	x_coord = np.array(x_coord);
	H = np.array(H);
	bathymetry = np.array(bathymetry);
	discharge = np.array(discharge);
	waterSurfHeight = np.array(waterSurfHeight);

	return x_coord, H, bathymetry, discharge, waterSurfHeight

#def interpolate_nodal_values(triangulation, NodalVals, query_x, query_y):
#	f = triInterp(triangulation, NodalVals)
#	#f = interp2d(Nodal_x, Nodal_y, NodalVals,kind='cubic')
#	interpolated_values = f(query_x, query_y)
#
#	return interpolated_values


	



